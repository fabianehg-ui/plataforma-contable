# v2.1.5 — Mejora del clasificador de conceptos

## Qué cambia

Solo cambia **una sección del archivo `borrador_facil_350.py`**: la
función `clasificar_concepto_por_cuenta()` que decide a qué concepto
del Formulario 350 corresponde cada movimiento del auxiliar de Contai.

**No cambia** la lógica de tarifas, casillas, generación de PDF, base
de datos ni interfaz. La firma de la función es idéntica, así que el
resto del programa sigue funcionando sin tocar nada más.

## Por qué

El clasificador anterior usaba `if/elif` con palabras sueltas y a veces
clasificaba mal cuando el nombre tenía palabras ambiguas. Casos típicos
que fallaban antes:

- "VIGILANCIA FISCAL" → se clasificaba como Servicios (era Honorarios).
- "CONSULTORIA EN SISTEMAS" → caía a Otros pagos.
- "FRANQUICIA McDonalds" → no reconocía franquicia como regalía sin el
  texto "regalía" presente.
- "TRANSPORTE DE CARGA" → caía a Otros pagos.
- Cualquier nombre vacío o solo con código PUC → daba Otros pagos.

## Cómo funciona ahora

El nuevo clasificador evalúa **tres niveles de reglas en orden de
confianza**, parando en el primero que coincide:

1. **Código PUC exacto** — la cuenta 23-65-XX-XX del PUC colombiano
   tiene significado fijo (Decreto 2650 de 1993). Si la cuenta del
   auxiliar empieza con `23-65-15` o `236515`, va directo a Honorarios
   con confianza alta. No depende del nombre.

2. **Patrones combinados** — la palabra principal solo cuenta si
   aparece junto a una de las palabras secundarias. Ejemplo:
   `"VIGILANCIA"` exige que también aparezca `"PRIVADA"` o `"SEGURIDAD"`
   para clasificar como Servicios; si en cambio aparece junto a
   `"FISCAL"`, va a Honorarios.

3. **Palabras clave individuales** — si nada de lo anterior calza,
   busca palabras simples como antes, pero con confianza media.

Si nada matchea → `Otros pagos` con confianza baja (igual que antes).

## Confianza

Ahora cada clasificación reporta `alta`, `media` o `baja`:

- **alta** — clasificación basada en código PUC o patrón combinado
  específico. Casi seguro no requiere revisión.
- **media** — clasificación por palabra clave o regla aproximada.
  Conviene revisar antes de presentar.
- **baja** — fallback a "Otros pagos". Casi seguro requiere
  reclasificación manual.

La nueva función `clasificar_concepto_detallado()` retorna toda esta
información. La función `clasificar_concepto_por_cuenta()` original
sigue devolviendo solo el string del concepto (compatibilidad total).

## Cómo aplicar

### Opción 1: reemplazar el archivo completo (más fácil)

1. Haz una copia de seguridad de tu `borrador_facil_350.py` actual.
2. Reemplaza con el archivo nuevo que viene en este zip.
3. Ejecuta la app normalmente (`EJECUTAR_APP.bat`).

### Opción 2: aplicar solo el patch (más limpio para git)

Desde la carpeta del repo en Git Bash:

```bash
git checkout -b mejora-clasificador
# Copia mejora_clasificador.patch al directorio del repo
git apply --check mejora_clasificador.patch   # prueba primero
git apply mejora_clasificador.patch           # aplica los cambios
python -c "import ast; ast.parse(open('borrador_facil_350.py').read()); print('OK')"
```

## Cómo probar

Ejecuta `test_clasificador.py`:

```bash
python test_clasificador.py
```

Debería salir `26 OK, 0 FALLAN`.

## Pendiente para próximas versiones

- Actualizar tarifas de autorretención al régimen vigente desde el
  8 de mayo de 2026 (Dec. 0261/2023 + 0242/2024) tras la suspensión
  del Dec. 0572/2025.
- Mejorar la lectura del balance para soportar cuentas a 6 dígitos
  sin guiones.
- UI para que el usuario revise visualmente los movimientos de
  confianza media/baja antes de generar el F350.

