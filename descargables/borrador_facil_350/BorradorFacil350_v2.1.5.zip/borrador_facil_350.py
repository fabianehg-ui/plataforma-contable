"""
BorradorFacil 350 - Aplicación de Escritorio
Autor: Proyecto de contadora colombiana
Descripción: Genera borradores del Formulario 350 DIAN
Licencia: Propietaria - uso exclusivo del comprador
Versión: 1.0.0
"""

import tkinter as tk
from tkinter import ttk, messagebox, filedialog
import sqlite3
import os
import sys
import re
from datetime import datetime
from decimal import Decimal, ROUND_HALF_UP

try:
    import pdfplumber
    PDF_DISPONIBLE = True
except ImportError:
    PDF_DISPONIBLE = False

# ==========================================================
# CONFIGURACIÓN GLOBAL
# ==========================================================
APP_NAME = "BorradorFácil 350"
APP_VERSION = "2.1.4"
DB_FILE = "borrador_facil_350.db"

# Colores del tema (profesional, sobrio)
COLOR_PRIMARY = "#1F4E78"      # Azul corporativo
COLOR_SECONDARY = "#D9E1F2"    # Azul claro para fondos
COLOR_SUCCESS = "#E2EFDA"      # Verde confirmación
COLOR_WARNING = "#FFF2CC"      # Amarillo alerta
COLOR_DANGER = "#FCE4D6"       # Rojo suave
COLOR_TEXT = "#000000"
COLOR_TEXT_SECONDARY = "#666666"
COLOR_BG = "#FFFFFF"


# ==========================================================
# UTILIDADES TRIBUTARIAS (lógica de negocio)
# ==========================================================

def inferir_tipo_persona(nit_str):
    """
    Aplica la regla oficial del NIT colombiano.
    Retorna: (tipo, es_extranjero, es_valido, rango)
    """
    try:
        # Limpiar el NIT
        nit_limpio = ''.join(c for c in str(nit_str) if c.isdigit())
        nit = int(nit_limpio)
    except (ValueError, TypeError):
        return ("REVISAR", False, False, "NIT inválido")

    if 10_000 <= nit <= 99_999_999:
        return ("Persona Natural", False, True, "Cédula antigua")
    if 600_000_000 <= nit <= 799_999_999:
        return ("Persona Natural", True, True, "NIT DIAN extranjero")
    if 800_000_000 <= nit <= 999_999_999:
        return ("Persona Jurídica", False, True, "NIT DIAN empresa")
    if 1_000_000_000 <= nit <= 1_999_999_999:
        return ("Persona Natural", False, True, "Cédula moderna")

    return ("REVISAR", False, False, "Fuera de rangos conocidos")


def calcular_dv(nit_str):
    """
    Calcula el dígito de verificación del NIT colombiano según algoritmo oficial DIAN.
    """
    try:
        nit_limpio = ''.join(c for c in str(nit_str) if c.isdigit())
        if not nit_limpio:
            return ""
        factores = [3, 7, 13, 17, 19, 23, 29, 37, 41, 43, 47, 53, 59, 67, 71]
        # Invertir el NIT y multiplicar por factores
        suma = 0
        nit_invertido = nit_limpio[::-1]
        for i, digito in enumerate(nit_invertido):
            if i < len(factores):
                suma += int(digito) * factores[i]
        residuo = suma % 11
        if residuo < 2:
            return str(residuo)
        return str(11 - residuo)
    except Exception:
        return ""


def formato_moneda(valor):
    """Formato colombiano: $1.234.567"""
    try:
        num = int(round(float(valor)))
        return f"${num:,}".replace(",", ".")
    except (ValueError, TypeError):
        return "$0"


def formato_nit(nit_str):
    """Formato colombiano: 900.451.388-1"""
    try:
        nit_limpio = ''.join(c for c in str(nit_str) if c.isdigit())
        if len(nit_limpio) < 4:
            return nit_str
        dv = calcular_dv(nit_limpio)
        # Formatear con puntos cada 3 dígitos
        num = int(nit_limpio)
        formateado = f"{num:,}".replace(",", ".")
        return f"{formateado}-{dv}"
    except Exception:
        return nit_str


# ==========================================================
# PARSERS DE PDFs DE CONTAI
# ==========================================================

def parsear_auxiliar_contai(ruta_pdf):
    """
    Parsea el reporte 'Análisis de % de Retención e IVA - Resumido' de Contai.

    Estructura:
    - Encabezado empresa: "NOMBRE S.A.S - NIT"
    - Encabezado cuenta: "CODIGO NOMBRE_CUENTA" (ej: "23-65-25-05 SERVICIOS DEL 4%")
    - Líneas movimiento: "[debitos?] creditos base tarifa NIT nombre_tercero"
    - Total Cuenta: cierra cada grupo

    Retorna dict con: empresa, nit_empresa, periodo, movimientos[]
    """
    if not PDF_DISPONIBLE:
        raise RuntimeError("pdfplumber no está instalado. Instálalo con: pip install pdfplumber")

    movimientos = []
    empresa = None
    nit_empresa = None
    periodo = None

    with pdfplumber.open(ruta_pdf) as pdf:
        for page in pdf.pages:
            texto = page.extract_text()
            if not texto:
                continue
            lineas = texto.split('\n')

            cuenta_actual = None
            nombre_cuenta_actual = None
            tarifa_actual = None

            for linea in lineas:
                linea = linea.strip()
                if not linea:
                    continue

                if 'S.A.S' in linea and '-' in linea and not empresa:
                    m = re.match(r'(.+?)\s*-\s*([\d\.]+-?\d?)', linea)
                    if m:
                        empresa = m.group(1).strip()
                        nit_empresa = m.group(2).strip()

                if not periodo:
                    m = re.search(r'([A-Z][a-z]{2}-\d{1,2}-\d{4})', linea)
                    if m:
                        periodo = m.group(1)

                if (linea.startswith('---') or linea.startswith('===')
                    or 'PAGINA' in linea or 'Contai' in linea
                    or ('Cuenta' in linea and 'Nombre' in linea and 'NIT' in linea)):
                    continue

                m_cuenta = re.match(r'^(\d{2}-\d{2}-\d{2}-\d{2})\s+(.+)$', linea)
                if m_cuenta:
                    cuenta_actual = m_cuenta.group(1)
                    nombre_completo = m_cuenta.group(2).strip()
                    m_tarifa = re.search(r'(\d+(?:\.\d+)?)\s*%?\s*$', nombre_completo)
                    if m_tarifa:
                        try:
                            tarifa_actual = float(m_tarifa.group(1))
                            nombre_cuenta_actual = nombre_completo[:m_tarifa.start()].strip()
                        except ValueError:
                            tarifa_actual = None
                            nombre_cuenta_actual = nombre_completo
                    else:
                        tarifa_actual = None
                        nombre_cuenta_actual = nombre_completo
                    continue

                if linea.startswith('Total Cuenta') or linea.startswith('Total General'):
                    cuenta_actual = None
                    continue

                if cuenta_actual:
                    m_mov = re.match(
                        r'^([\d,\.]+(?:\s+[\d,\.]+){1,2})\s+(\d+(?:\.\d+)?)\s+(\d+)\s+(.+)$',
                        linea
                    )
                    if m_mov:
                        try:
                            numeros_str = m_mov.group(1)
                            tarifa_mov = float(m_mov.group(2))
                            nit = m_mov.group(3)
                            nombre_tercero = m_mov.group(4).strip()

                            nums = [float(n.replace(',', ''))
                                    for n in re.findall(r'[\d,\.]+', numeros_str)]

                            if len(nums) == 2:
                                debitos = 0.0
                                creditos, base = nums
                            elif len(nums) == 3:
                                debitos, creditos, base = nums
                            else:
                                continue

                            retencion = creditos - debitos

                            movimientos.append({
                                'cuenta': cuenta_actual,
                                'nombre_cuenta': nombre_cuenta_actual,
                                'tarifa_cuenta': tarifa_actual,
                                'debitos': debitos,
                                'creditos': creditos,
                                'base': base,
                                'tarifa_mov': tarifa_mov,
                                'retencion': retencion,
                                'nit': nit,
                                'nombre_tercero': nombre_tercero,
                            })
                        except (ValueError, IndexError):
                            continue

    return {
        'empresa': empresa,
        'nit_empresa': nit_empresa,
        'periodo': periodo,
        'movimientos': movimientos,
    }


def parsear_balance_contai(ruta_pdf):
    """
    Parsea 'Balance de Prueba por Cuenta (Normal)' de Contai.

    Estructura línea: CODIGO NOMBRE SALDO_ANT DEBITOS CREDITOS NUEVO_SALDO
    Códigos: de 1 dígito (clase) hasta 4 niveles (11-05-05-01).

    Retorna dict con: empresa, nit_empresa, cuentas[]
    """
    if not PDF_DISPONIBLE:
        raise RuntimeError("pdfplumber no está instalado")

    empresa = None
    nit_empresa = None
    cuentas = []

    with pdfplumber.open(ruta_pdf) as pdf:
        for page in pdf.pages:
            texto = page.extract_text()
            if not texto:
                continue
            lineas = texto.split('\n')

            for linea in lineas:
                linea = linea.strip()
                if not linea:
                    continue

                if 'S.A.S' in linea and '-' in linea and not empresa:
                    m = re.match(r'(.+?)\s*-\s*([\d\.]+-?\d?)', linea)
                    if m:
                        empresa = m.group(1).strip()
                        nit_empresa = m.group(2).strip()

                if (linea.startswith('---') or linea.startswith('===')
                    or 'PAGINA' in linea or 'Contai' in linea
                    or 'M o v i m' in linea
                    or ('Código' in linea and 'Nombre' in linea)
                    or linea.startswith('Débitos')
                    or linea.startswith('Créditos')
                    or linea.startswith('T o t a l e s')):
                    continue

                m = re.match(
                    r'^(\d{1,2}(?:-\d{2}){0,3})\s+(.+?)\s+(-?[\d,\.]+)\s+(-?[\d,\.]+)\s+(-?[\d,\.]+)\s+(-?[\d,\.]+)$',
                    linea
                )
                if m:
                    codigo = m.group(1)
                    nombre = m.group(2).strip()
                    try:
                        saldo_ant = float(m.group(3).replace(',', ''))
                        debitos = float(m.group(4).replace(',', ''))
                        creditos = float(m.group(5).replace(',', ''))
                        nuevo_saldo = float(m.group(6).replace(',', ''))
                    except ValueError:
                        continue

                    cuentas.append({
                        'codigo': codigo,
                        'nivel': codigo.count('-') + 1,
                        'nombre': nombre,
                        'saldo_anterior': saldo_ant,
                        'debitos': debitos,
                        'creditos': creditos,
                        'nuevo_saldo': nuevo_saldo,
                    })

    return {
        'empresa': empresa,
        'nit_empresa': nit_empresa,
        'cuentas': cuentas,
    }


def calcular_autorretencion_cuenta_4(balance_data, tarifa):
    """
    Calcula autorretención sobre TODA la cuenta 4 (ingresos).
    Base = créditos - débitos de la clase 4 en el período.
    """
    cuenta_4 = None
    cuenta_41 = None
    cuenta_42 = None

    for c in balance_data['cuentas']:
        if c['codigo'] == '4':
            cuenta_4 = c
        elif c['codigo'] == '41':
            cuenta_41 = c
        elif c['codigo'] == '42':
            cuenta_42 = c

    if not cuenta_4:
        return None

    ingresos_netos = cuenta_4['creditos'] - cuenta_4['debitos']
    autorretencion = round(ingresos_netos * tarifa / 100)

    return {
        'cuenta_4_creditos': cuenta_4['creditos'],
        'cuenta_4_debitos': cuenta_4['debitos'],
        'ingresos_netos': ingresos_netos,
        'tarifa_aplicada': tarifa,
        'autorretencion': autorretencion,
        'cuenta_41_neto': (cuenta_41['creditos'] - cuenta_41['debitos']) if cuenta_41 else 0,
        'cuenta_42_neto': (cuenta_42['creditos'] - cuenta_42['debitos']) if cuenta_42 else 0,
    }


MAPEO_CASILLAS_F350 = {
    "Honorarios":              {"PJ": (29, 42),     "PN": (79, 95)},
    "Comisiones":              {"PJ": (30, 43),     "PN": (80, 96)},
    "Servicios":               {"PJ": (31, 44),     "PN": (81, 97)},
    "Rendimientos financieros":{"PJ": (32, 45),     "PN": (82, 98)},
    "Arrendamientos":          {"PJ": (33, 46),     "PN": (83, 99)},
    "Regalías":                {"PJ": (34, 47),     "PN": (84, 100)},
    "Dividendos":              {"PJ": (35, 48),     "PN": (85, 101)},
    "Compras":                 {"PJ": (36, 49),     "PN": (86, 102)},
    "Contratos construcción":  {"PJ": (38, 51),     "PN": (88, 104)},
    "Loterías rifas":          {"PJ": (39, 52),     "PN": (90, 106)},
    "Otros pagos":             {"PJ": (41, 54),     "PN": (92, 108)},
    "Rentas de trabajo":       {"PJ": (None, None), "PN": (77, 93)},
}

AUTORRET_CASILLAS_F350 = {
    "Contribuyentes exonerados 114-1": (59, 68),
    "Ventas":                          (60, 69),
    "Honorarios":                      (61, 70),
    "Comisiones":                      (62, 71),
    "Servicios":                       (63, 72),
    "Rendimientos financieros":        (64, 73),
    "Otros conceptos":                 (67, 76),
}


# ==========================================================
# CLASIFICACIÓN DE CONCEPTOS DEL F350
# ==========================================================
#
# Estrategia (en orden de prioridad descendente):
#
#   1. CÓDIGO PUC EXACTO  → la cuenta 23-65-XX del PUC colombiano tiene
#      significado fijo definido por el Decreto 2650 de 1993. Es la
#      fuente más confiable.
#
#   2. PATRONES COMBINADOS → palabras que solo califican cuando aparecen
#      junto a otras (ej: "VIGILANCIA FISCAL" es honorarios, mientras
#      que "VIGILANCIA PRIVADA" es servicios).
#
#   3. PALABRAS CLAVE INDIVIDUALES → la última red de seguridad cuando
#      no hay código PUC o el nombre es ambiguo.
#
# Cada regla devuelve además un nivel de confianza (alta/media/baja)
# para que la UI pueda resaltar movimientos que probablemente requieran
# revisión manual.
#
# Para agregar reglas nuevas sin tocar el código: añade entradas a
# REGLAS_CODIGO_PUC, REGLAS_PATRON_COMBINADO o REGLAS_PALABRA_CLAVE.
# ==========================================================

# --- 1. Reglas por código PUC -----------------------------------------
# Llave: prefijo de código (con o sin guiones). Valor: (concepto, confianza).
# Los prefijos más específicos (más largos) se evalúan primero.
REGLAS_CODIGO_PUC = {
    # Retenciones IVA (toda la cuenta 2367 / 23-67)
    "2367":     ("IVA", "alta"),
    "23-67":    ("IVA", "alta"),

    # Retenciones renta — cuenta 2365 / 23-65
    "236505":   ("Rentas de trabajo", "alta"),
    "23-65-05": ("Rentas de trabajo", "alta"),
    "236510":   ("Dividendos", "alta"),
    "23-65-10": ("Dividendos", "alta"),
    "236515":   ("Honorarios", "alta"),
    "23-65-15": ("Honorarios", "alta"),
    "236520":   ("Comisiones", "alta"),
    "23-65-20": ("Comisiones", "alta"),
    "236525":   ("Servicios", "alta"),
    "23-65-25": ("Servicios", "alta"),
    "236530":   ("Arrendamientos", "alta"),
    "23-65-30": ("Arrendamientos", "alta"),
    "236535":   ("Rendimientos financieros", "alta"),
    "23-65-35": ("Rendimientos financieros", "alta"),
    "236540":   ("Compras", "alta"),
    "23-65-40": ("Compras", "alta"),
    "236545":   ("Loterías rifas", "alta"),
    "23-65-45": ("Loterías rifas", "alta"),
    "236550":   ("Otros pagos", "alta"),  # Por pagos al exterior
    "23-65-50": ("Otros pagos", "alta"),
    "236555":   ("Otros pagos", "alta"),  # Por pagos al exterior renta
    "23-65-55": ("Otros pagos", "alta"),
    "236560":   ("Compras", "alta"),  # Compras de café
    "23-65-60": ("Compras", "alta"),
    "236565":   ("Honorarios", "alta"),  # Por enajenación propiedad raíz P.N.
    "23-65-65": ("Honorarios", "alta"),
    "236570":   ("Contratos construcción", "alta"),
    "23-65-70": ("Contratos construcción", "alta"),
    "236575":   ("Servicios", "alta"),  # Por pagos al exterior servicios técnicos
    "23-65-75": ("Servicios", "alta"),
    "236580":   ("Compras", "media"),
    "23-65-80": ("Compras", "media"),
    "236595":   ("Otros pagos", "media"),
    "23-65-95": ("Otros pagos", "media"),
    "236599":   ("Otros pagos", "baja"),
    "23-65-99": ("Otros pagos", "baja"),
}

# --- 2. Patrones combinados (palabra_principal, palabras_secundarias, concepto, confianza) ----
# Se evalúa: ¿está la palabra_principal Y al menos una de las secundarias en el nombre?
# (lista vacía de secundarias = solo necesita la principal)
REGLAS_PATRON_COMBINADO = [
    # === Pagos al exterior — tienen prioridad sobre todo lo demás
    # porque la casilla F350 los manda a la sección de no residentes
    # independientemente del tipo de servicio prestado.
    ("EXTERIOR",        [],                                              "Otros pagos", "alta"),
    ("NO RESIDENTE",    [],                                              "Otros pagos", "alta"),
    ("EXTRANJERO",      ["PAGO", "RETENCION"],                           "Otros pagos", "alta"),

    # IVA — variantes de escritura
    ("RETEIVA",         [],                                              "IVA", "alta"),
    ("RETE IVA",        [],                                              "IVA", "alta"),
    ("RETENCION IVA",   [],                                              "IVA", "alta"),
    ("RETENCIÓN IVA",   [],                                              "IVA", "alta"),

    # Rentas de trabajo — agrupa salarios y conceptos laborales
    ("SALARIO",         [],                                              "Rentas de trabajo", "alta"),
    ("NOMINA",          ["RETENCION", "RETEFUENTE"],                     "Rentas de trabajo", "alta"),
    ("NÓMINA",          ["RETENCION", "RETEFUENTE"],                     "Rentas de trabajo", "alta"),
    ("LABORAL",         ["RETENCION", "PAGO"],                           "Rentas de trabajo", "alta"),
    ("TRABAJO",         ["RENTA", "RENTAS"],                             "Rentas de trabajo", "alta"),

    # Honorarios y profesionales
    ("HONORARIO",       [],                                              "Honorarios", "alta"),
    ("CONSULTORIA",     [],                                              "Honorarios", "alta"),
    ("CONSULTORÍA",     [],                                              "Honorarios", "alta"),
    ("ASESORIA",        ["TECNICA", "PROFESIONAL", "JURIDICA", "CONTABLE", "TRIBUTARIA", "FINANCIERA"], "Honorarios", "alta"),
    ("ASESORÍA",        ["TÉCNICA", "PROFESIONAL", "JURÍDICA", "CONTABLE", "TRIBUTARIA", "FINANCIERA"], "Honorarios", "alta"),
    ("REVISORIA",       ["FISCAL"],                                      "Honorarios", "alta"),
    ("REVISORÍA",       ["FISCAL"],                                      "Honorarios", "alta"),
    ("VIGILANCIA",      ["FISCAL"],                                      "Honorarios", "alta"),

    # Comisiones
    ("COMISION",        [],                                              "Comisiones", "alta"),
    ("COMISIÓN",        [],                                              "Comisiones", "alta"),
    ("INTERMEDIACION",  [],                                              "Comisiones", "media"),
    ("INTERMEDIACIÓN",  [],                                              "Comisiones", "media"),

    # Servicios
    ("SERVICIO",        [],                                              "Servicios", "alta"),
    ("ASEO",            [],                                              "Servicios", "alta"),
    ("VIGILANCIA",      ["PRIVADA", "SEGURIDAD"],                        "Servicios", "alta"),
    ("MANTENIMIENTO",   [],                                              "Servicios", "media"),
    ("REPARACION",      [],                                              "Servicios", "media"),
    ("REPARACIÓN",      [],                                              "Servicios", "media"),
    ("CAPACITACION",    [],                                              "Servicios", "alta"),
    ("CAPACITACIÓN",    [],                                              "Servicios", "alta"),
    ("FLETE",           [],                                              "Servicios", "alta"),
    ("TRANSPORTE",      ["CARGA", "MERCANCIA", "MERCANCÍA"],              "Servicios", "alta"),
    ("LICENCIAM",       [],                                              "Servicios", "alta"),
    ("HOSTING",         [],                                              "Servicios", "alta"),
    ("PUBLICIDAD",      [],                                              "Servicios", "alta"),
    ("VALLA",           ["PUBLICITARIA"],                                "Servicios", "alta"),

    # Arrendamientos
    ("ARRENDAMIENT",    [],                                              "Arrendamientos", "alta"),
    ("ALQUILER",        [],                                              "Arrendamientos", "alta"),
    ("CANON",           ["ARRENDAMIENTO"],                               "Arrendamientos", "alta"),

    # Regalías y franquicia
    ("REGALIA",         [],                                              "Regalías", "alta"),
    ("REGALÍA",         [],                                              "Regalías", "alta"),
    ("FRANQUICIA",      [],                                              "Regalías", "alta"),
    ("LICENCIA",        ["USO", "MARCA", "EXPLOTACION", "EXPLOTACIÓN"],  "Regalías", "alta"),
    ("PROPIEDAD",       ["INTELECTUAL", "INDUSTRIAL"],                   "Regalías", "alta"),

    # Dividendos
    ("DIVIDENDO",       [],                                              "Dividendos", "alta"),
    ("PARTICIPACION",   ["SOCIAL", "UTILIDAD"],                          "Dividendos", "media"),
    ("PARTICIPACIÓN",   ["SOCIAL", "UTILIDAD"],                          "Dividendos", "media"),

    # Construcción
    ("CONSTRUCCION",    [],                                              "Contratos construcción", "alta"),
    ("CONSTRUCCIÓN",    [],                                              "Contratos construcción", "alta"),
    ("OBRA",            ["CIVIL", "CONSTRUCCION", "CONSTRUCCIÓN"],       "Contratos construcción", "alta"),

    # Loterías y juegos
    ("LOTER",           [],                                              "Loterías rifas", "alta"),
    ("RIFA",            [],                                              "Loterías rifas", "alta"),
    ("APUEST",          [],                                              "Loterías rifas", "alta"),
    ("PREMIO",          ["JUEGO", "AZAR", "SORTEO"],                     "Loterías rifas", "alta"),

    # Rendimientos financieros
    ("RENDIMIENTO",     ["FINANCIERO"],                                  "Rendimientos financieros", "alta"),
    ("INTERES",         ["FINANCIERO", "CDT", "PRESTAMO", "PRÉSTAMO"],   "Rendimientos financieros", "alta"),
    ("INTERÉS",         ["FINANCIERO", "CDT", "PRESTAMO", "PRÉSTAMO"],   "Rendimientos financieros", "alta"),
    ("DESCUENTO",       ["FINANCIERO"],                                  "Rendimientos financieros", "alta"),

    # Compras
    ("COMPRA",          [],                                              "Compras", "alta"),
    ("ADQUISICION",     ["BIEN", "MERCANCIA", "MERCANCÍA"],              "Compras", "alta"),
    ("ADQUISICIÓN",     ["BIEN", "MERCANCIA", "MERCANCÍA"],              "Compras", "alta"),
    ("CAFE",            ["COMPRA"],                                      "Compras", "alta"),
    ("CAFÉ",            ["COMPRA"],                                      "Compras", "alta"),
]

# --- 3. Palabras clave individuales (último recurso) ------------------
REGLAS_PALABRA_CLAVE = [
    ("HONORARIO",      "Honorarios", "media"),
    ("COMISION",       "Comisiones", "media"),
    ("COMISIÓN",       "Comisiones", "media"),
    ("ARRENDAMIENT",   "Arrendamientos", "media"),
    ("ALQUILER",       "Arrendamientos", "media"),
    ("SERVICIO",       "Servicios", "media"),
    ("COMPRA",         "Compras", "media"),
    ("DIVIDENDO",      "Dividendos", "media"),
    ("REGALIA",        "Regalías", "media"),
    ("REGALÍA",        "Regalías", "media"),
    ("CONSTRUCCION",   "Contratos construcción", "media"),
    ("CONSTRUCCIÓN",   "Contratos construcción", "media"),
    ("LOTER",          "Loterías rifas", "media"),
    ("RIFA",           "Loterías rifas", "media"),
    ("SALARIO",        "Rentas de trabajo", "media"),
    ("LABORAL",        "Rentas de trabajo", "media"),
    ("RENDIMIENTO",    "Rendimientos financieros", "media"),
    ("FINANCIERO",     "Rendimientos financieros", "baja"),
    ("EXTERIOR",       "Otros pagos", "media"),
]


def _normalizar_codigo(codigo):
    """Devuelve el código sin guiones para comparaciones por prefijo."""
    if not codigo:
        return ""
    return str(codigo).replace("-", "").replace(".", "").strip()


def _coincide_prefijo_puc(codigo_sin_guiones, prefijo):
    """¿El código empieza con el prefijo (también sin guiones)?"""
    prefijo_limpio = _normalizar_codigo(prefijo)
    return prefijo_limpio and codigo_sin_guiones.startswith(prefijo_limpio)


def clasificar_concepto_detallado(cuenta_contai, nombre_cuenta):
    """
    Versión extendida de clasificar_concepto_por_cuenta() que también
    devuelve la regla aplicada y un nivel de confianza.

    Retorna dict con:
      - 'concepto'   : str (uno de los conceptos del F350)
      - 'confianza'  : 'alta' | 'media' | 'baja'
      - 'origen'     : 'codigo_puc' | 'patron_combinado' | 'palabra_clave' | 'default'
      - 'regla'      : str descriptiva de la regla que disparó la clasificación
    """
    nombre_upper = (nombre_cuenta or "").upper()
    codigo_limpio = _normalizar_codigo(cuenta_contai)

    # ---- 1. Reglas por código PUC (prefijos más largos primero) ----
    if codigo_limpio:
        prefijos_ordenados = sorted(REGLAS_CODIGO_PUC.keys(),
                                    key=lambda k: -len(_normalizar_codigo(k)))
        for prefijo in prefijos_ordenados:
            if _coincide_prefijo_puc(codigo_limpio, prefijo):
                concepto, conf = REGLAS_CODIGO_PUC[prefijo]
                return {
                    "concepto":  concepto,
                    "confianza": conf,
                    "origen":    "codigo_puc",
                    "regla":     f"Código PUC {prefijo}",
                }

    # ---- 2. Patrones combinados (palabra principal + secundarias) ----
    for principal, secundarias, concepto, conf in REGLAS_PATRON_COMBINADO:
        if principal in nombre_upper:
            if not secundarias:
                return {
                    "concepto":  concepto,
                    "confianza": conf,
                    "origen":    "patron_combinado",
                    "regla":     f"Nombre contiene '{principal}'",
                }
            for sec in secundarias:
                if sec in nombre_upper:
                    return {
                        "concepto":  concepto,
                        "confianza": conf,
                        "origen":    "patron_combinado",
                        "regla":     f"Nombre contiene '{principal}' + '{sec}'",
                    }

    # ---- 3. Palabras clave individuales ----
    for palabra, concepto, conf in REGLAS_PALABRA_CLAVE:
        if palabra in nombre_upper:
            return {
                "concepto":  concepto,
                "confianza": conf,
                "origen":    "palabra_clave",
                "regla":     f"Palabra clave '{palabra}'",
            }

    # ---- 4. Default: Otros pagos con confianza baja ----
    return {
        "concepto":  "Otros pagos",
        "confianza": "baja",
        "origen":    "default",
        "regla":     "Sin coincidencias — clasificado por defecto",
    }


def clasificar_concepto_por_cuenta(cuenta_contai, nombre_cuenta):
    """
    Dada una cuenta del PUC y su nombre, retorna el CONCEPTO del F350
    al que corresponde (string).

    Mantenida por compatibilidad. Para más información sobre cómo se
    clasificó un movimiento (confianza, regla aplicada), usar
    clasificar_concepto_detallado().
    """
    return clasificar_concepto_detallado(cuenta_contai, nombre_cuenta)["concepto"]


def obtener_casillas_f350(concepto, tipo_tercero, es_extranjero=False):
    """
    Dado un concepto (ej. 'Servicios') y tipo ('PJ' o 'PN'),
    retorna tupla (casilla_base, casilla_retencion) del formulario 350.
    """
    if es_extranjero:
        return (55, 57)

    tipo_key = "PN" if tipo_tercero == "Persona Natural" else "PJ"
    if concepto in MAPEO_CASILLAS_F350:
        return MAPEO_CASILLAS_F350[concepto][tipo_key]
    return (41, 54) if tipo_key == "PJ" else (92, 108)


def mapear_cuenta_contai_a_casilla(cuenta_contai, nombre_cuenta):
    """DEPRECATED - mantiene compatibilidad. Usa obtener_casillas_f350() en código nuevo."""
    concepto = clasificar_concepto_por_cuenta(cuenta_contai, nombre_cuenta)
    cas_base, cas_ret = obtener_casillas_f350(concepto, "Persona Jurídica")
    return cas_ret if cas_ret else 54


# ==========================================================
# GENERADOR PDF DEL FORMULARIO 350 (estilo DIAN)
# ==========================================================

def _fmt_num_f350(n):
    if n is None or n == 0:
        return "0"
    try:
        return f"{int(round(n)):,}".replace(",", ".")
    except (ValueError, TypeError):
        return "0"


def aproximar_a_miles(valor):
    """
    Aproxima un valor al múltiplo de mil más cercano.
    Regla DIAN (Art. 577 ET):
    - Últimos 3 dígitos ≥ 500 → redondear hacia arriba
    - Últimos 3 dígitos < 500 → redondear hacia abajo

    Usa redondeo tradicional (HALF_UP), no el "bancario" de round().

    Ejemplos:
      $550.000  → $550.000 (ya es múltiplo de mil)
      $61.000   → $61.000
      $450.400  → $450.000 (los últimos 3 dígitos son 400, redondea abajo)
      $450.500  → $451.000 (los últimos 3 dígitos son 500, redondea arriba)
      $7.993.164 → $7.993.000 (164 < 500)
      $726.651.300 → $726.651.000 (300 < 500)
    """
    if valor is None or valor == 0:
        return 0
    try:
        from decimal import Decimal, ROUND_HALF_UP
        d = Decimal(str(valor)) / Decimal("1000")
        aproximado = d.quantize(Decimal("1"), rounding=ROUND_HALF_UP)
        return int(aproximado) * 1000
    except (ValueError, TypeError):
        return 0


def generar_pdf_formulario_350(ruta_salida, datos):
    """
    Genera PDF del F350 con layout similar al oficial DIAN.
    datos: dict con año, periodo, nit, dv, razon_social, ciiu, tarifa_autorret,
           retenciones[{concepto, tipo, base, retencion}], autorretenciones[]
    """
    try:
        from reportlab.lib.pagesizes import letter
        from reportlab.lib.units import cm
        from reportlab.lib.colors import HexColor, white, black, grey
        from reportlab.pdfgen import canvas
    except ImportError:
        raise RuntimeError("reportlab no está instalado. Instala con: pip install reportlab")

    AZUL_DIAN = HexColor("#1F4E78")
    GRIS_CLARO = HexColor("#F2F2F2")
    AMARILLO = HexColor("#FFF9E6")

    c = canvas.Canvas(ruta_salida, pagesize=letter)
    ancho, alto = letter

    c.saveState()
    c.setFont("Helvetica-Bold", 64)
    c.setFillColor(HexColor("#FFE5E5"))
    c.translate(ancho/2, alto/2)
    c.rotate(45)
    c.drawCentredString(0, 0, "BORRADOR")
    c.restoreState()

    y = alto - 1.2*cm
    c.setFillColor(AZUL_DIAN)
    c.setStrokeColor(AZUL_DIAN)
    c.setLineWidth(1.5)
    c.rect(1.5*cm, y - 0.9*cm, 3*cm, 0.9*cm, fill=0, stroke=1)
    c.setFont("Helvetica-Bold", 18)
    c.drawCentredString(3*cm, y - 0.65*cm, "DIAN")

    c.setFillColor(AZUL_DIAN)
    c.rect(ancho - 3.5*cm, y - 0.9*cm, 2*cm, 0.9*cm, fill=1, stroke=0)
    c.setFillColor(white)
    c.setFont("Helvetica-Bold", 24)
    c.drawCentredString(ancho - 2.5*cm, y - 0.7*cm, "350")

    c.setFillColor(black)
    c.setFont("Helvetica-Bold", 12)
    c.drawCentredString(ancho/2, y - 0.4*cm, "Declaración retenciones en la fuente")
    c.setFont("Helvetica", 8)
    c.drawRightString(ancho - 4*cm, y - 0.75*cm, "PRIVADA")

    y -= 1.4*cm
    c.setStrokeColor(black)
    c.setLineWidth(0.5)

    c.rect(1.5*cm, y - 1.2*cm, 2.5*cm, 1.2*cm)
    c.setFont("Helvetica", 7)
    c.drawString(1.6*cm, y - 0.25*cm, "1. Año")
    c.setFont("Helvetica-Bold", 12)
    c.drawString(1.8*cm, y - 0.85*cm, str(datos['año']))

    c.rect(4*cm, y - 1.2*cm, 2*cm, 1.2*cm)
    c.setFont("Helvetica", 7)
    c.drawString(4.1*cm, y - 0.25*cm, "3. Período")
    c.setFont("Helvetica-Bold", 12)
    c.drawString(4.8*cm, y - 0.85*cm, str(datos['periodo']))

    c.rect(6*cm, y - 1.2*cm, ancho - 7.5*cm, 1.2*cm)
    c.setFont("Helvetica", 7)
    c.drawString(6.1*cm, y - 0.25*cm, "4. Número de formulario")
    c.setFont("Helvetica-Bold", 10)
    c.drawString(6.1*cm, y - 0.85*cm, "(Borrador - no asignado)")

    y -= 1.4*cm

    c.setFillColor(HexColor("#D9D9D9"))
    c.rect(1.5*cm, y - 0.5*cm, ancho - 3*cm, 0.5*cm, fill=1, stroke=1)
    c.setFillColor(black)
    c.setFont("Helvetica-Bold", 8)
    c.drawString(1.6*cm, y - 0.33*cm, "Datos del declarante")

    y -= 0.5*cm
    c.rect(1.5*cm, y - 1*cm, 5*cm, 1*cm)
    c.setFont("Helvetica", 7)
    c.drawString(1.6*cm, y - 0.2*cm, "5. NIT")
    c.setFont("Helvetica-Bold", 12)
    c.drawString(2.5*cm, y - 0.75*cm, datos['nit'])

    c.rect(6.5*cm, y - 1*cm, 1.2*cm, 1*cm)
    c.setFont("Helvetica", 7)
    c.drawString(6.6*cm, y - 0.2*cm, "6. DV")
    c.setFont("Helvetica-Bold", 12)
    c.drawCentredString(7.1*cm, y - 0.75*cm, datos['dv'])

    c.rect(7.7*cm, y - 1*cm, ancho - 9.2*cm, 1*cm)
    c.setFont("Helvetica", 7)
    c.drawString(7.8*cm, y - 0.2*cm, "11. Razón social")
    c.setFont("Helvetica-Bold", 11)
    c.drawString(7.8*cm, y - 0.75*cm, datos['razon_social'][:40])

    y -= 1.2*cm
    c.rect(1.5*cm, y - 1*cm, 4*cm, 1*cm)
    c.setFont("Helvetica", 7)
    c.drawString(1.6*cm, y - 0.2*cm, "27. CIIU principal")
    c.setFont("Helvetica-Bold", 11)
    c.drawString(1.8*cm, y - 0.75*cm, datos['ciiu'])

    c.rect(5.5*cm, y - 1*cm, 3*cm, 1*cm)
    c.setFont("Helvetica", 7)
    c.drawString(5.6*cm, y - 0.2*cm, "28. Tarifa autorret.")
    c.setFont("Helvetica-Bold", 11)
    c.drawString(5.8*cm, y - 0.75*cm, f"{datos['tarifa_autorret']:.1f} %")

    y -= 1.4*cm

    c.setFillColor(AZUL_DIAN)
    c.rect(1.5*cm, y - 0.5*cm, ancho - 3*cm, 0.5*cm, fill=1, stroke=1)
    c.setFillColor(white)
    c.setFont("Helvetica-Bold", 9)
    c.drawCentredString(ancho/2, y - 0.33*cm, "Retenciones a título de renta y complementario")

    y -= 0.5*cm
    c.setFillColor(black)

    ancho_concepto = 7*cm
    x_inicio = 1.5*cm
    alto_fila = 0.5*cm
    ancho_total = ancho - 3*cm
    ancho_seccion = (ancho_total - ancho_concepto) / 2
    mitad_sec = ancho_seccion / 2
    x_pj = x_inicio + ancho_concepto
    x_pn = x_pj + ancho_seccion

    c.setFillColor(GRIS_CLARO)
    c.rect(x_inicio, y - alto_fila, ancho_concepto, alto_fila, fill=1, stroke=1)
    c.setFillColor(black)
    c.setFont("Helvetica-Bold", 7)
    c.drawString(x_inicio + 0.1*cm, y - 0.32*cm, "Concepto")

    c.setFillColor(HexColor("#E8EEF4"))
    c.rect(x_pj, y - alto_fila, ancho_seccion, alto_fila, fill=1, stroke=1)
    c.setFillColor(black)
    c.drawCentredString(x_pj + ancho_seccion/2, y - 0.32*cm, "A personas jurídicas")

    c.setFillColor(HexColor("#FDF2E8"))
    c.rect(x_pn, y - alto_fila, ancho_seccion, alto_fila, fill=1, stroke=1)
    c.setFillColor(black)
    c.drawCentredString(x_pn + ancho_seccion/2, y - 0.32*cm, "A personas naturales")

    y -= alto_fila
    c.setFont("Helvetica", 6)
    c.rect(x_inicio, y - alto_fila, ancho_concepto, alto_fila)
    for x_ini in [x_pj, x_pn]:
        c.rect(x_ini, y - alto_fila, mitad_sec, alto_fila)
        c.drawCentredString(x_ini + mitad_sec/2, y - 0.32*cm, "Base")
        c.rect(x_ini + mitad_sec, y - alto_fila, mitad_sec, alto_fila)
        c.drawCentredString(x_ini + mitad_sec + mitad_sec/2, y - 0.32*cm, "Retención")

    y -= alto_fila

    conceptos_orden = [
        "Rentas de trabajo", "Honorarios", "Comisiones", "Servicios",
        "Rendimientos financieros", "Arrendamientos", "Regalías",
        "Dividendos", "Compras", "Contratos construcción",
        "Loterías rifas", "Otros pagos",
    ]

    retenciones_map = {}
    for r in datos.get('retenciones', []):
        key = (r['concepto'], r['tipo'])
        if key not in retenciones_map:
            retenciones_map[key] = {'base': 0, 'retencion': 0}
        retenciones_map[key]['base'] += r['base']
        retenciones_map[key]['retencion'] += r['retencion']

    total_ret_renta = 0
    c.setFont("Helvetica", 7)

    for concepto in conceptos_orden:
        if concepto not in MAPEO_CASILLAS_F350:
            continue

        pj_b, pj_r = MAPEO_CASILLAS_F350[concepto]["PJ"]
        pn_b, pn_r = MAPEO_CASILLAS_F350[concepto]["PN"]

        pj_raw = retenciones_map.get((concepto, "PJ"), {'base': 0, 'retencion': 0})
        pn_raw = retenciones_map.get((concepto, "PN"), {'base': 0, 'retencion': 0})
        pj_data = {'base': aproximar_a_miles(pj_raw['base']),
                   'retencion': aproximar_a_miles(pj_raw['retencion'])}
        pn_data = {'base': aproximar_a_miles(pn_raw['base']),
                   'retencion': aproximar_a_miles(pn_raw['retencion'])}
        total_ret_renta += pj_data['retencion'] + pn_data['retencion']

        c.rect(x_inicio, y - alto_fila, ancho_concepto, alto_fila)
        c.setFont("Helvetica", 7)
        c.drawString(x_inicio + 0.1*cm, y - 0.32*cm, concepto)

        for (x_col, casilla, valor) in [
            (x_pj, pj_b, pj_data['base']),
            (x_pj + mitad_sec, pj_r, pj_data['retencion']),
            (x_pn, pn_b, pn_data['base']),
            (x_pn + mitad_sec, pn_r, pn_data['retencion']),
        ]:
            if casilla is None:
                c.setFillColor(GRIS_CLARO)
                c.rect(x_col, y - alto_fila, mitad_sec, alto_fila, fill=1, stroke=1)
                c.setFillColor(black)
                continue
            if valor > 0:
                c.setFillColor(AMARILLO)
                c.rect(x_col, y - alto_fila, mitad_sec, alto_fila, fill=1, stroke=1)
                c.setFillColor(black)
            else:
                c.rect(x_col, y - alto_fila, mitad_sec, alto_fila)
            c.setFont("Helvetica", 6)
            c.setFillColor(grey)
            c.drawString(x_col + 0.08*cm, y - 0.18*cm, str(casilla))
            c.setFillColor(black)
            c.setFont("Helvetica-Bold" if valor > 0 else "Helvetica", 8)
            c.drawRightString(x_col + mitad_sec - 0.1*cm, y - 0.35*cm, _fmt_num_f350(valor))

        y -= alto_fila

    y -= 0.2*cm
    c.setFillColor(AZUL_DIAN)
    c.rect(1.5*cm, y - 0.5*cm, ancho - 3*cm, 0.5*cm, fill=1, stroke=1)
    c.setFillColor(white)
    c.setFont("Helvetica-Bold", 9)
    c.drawCentredString(ancho/2, y - 0.33*cm, "Autorretenciones")

    y -= 0.5*cm
    c.setFillColor(black)

    autorret_map = {a['concepto']: a for a in datos.get('autorretenciones', [])}
    total_autorret = 0
    c.setFont("Helvetica", 7)

    for concepto, (cas_base, cas_ret) in AUTORRET_CASILLAS_F350.items():
        raw = autorret_map.get(concepto, {'base': 0, 'retencion': 0})
        data = {'base': aproximar_a_miles(raw['base']),
                'retencion': aproximar_a_miles(raw['retencion'])}
        total_autorret += data['retencion']

        c.rect(x_inicio, y - alto_fila, ancho_concepto, alto_fila)
        c.drawString(x_inicio + 0.1*cm, y - 0.32*cm, concepto)

        if data['base'] > 0:
            c.setFillColor(AMARILLO)
            c.rect(x_pj, y - alto_fila, ancho_seccion, alto_fila, fill=1, stroke=1)
            c.setFillColor(black)
        else:
            c.rect(x_pj, y - alto_fila, mitad_sec, alto_fila)
            c.rect(x_pj + mitad_sec, y - alto_fila, mitad_sec, alto_fila)

        c.setFont("Helvetica", 6)
        c.setFillColor(grey)
        c.drawString(x_pj + 0.08*cm, y - 0.18*cm, str(cas_base))
        c.drawString(x_pj + mitad_sec + 0.08*cm, y - 0.18*cm, str(cas_ret))
        c.setFillColor(black)
        c.setFont("Helvetica-Bold" if data['base'] > 0 else "Helvetica", 8)
        c.drawRightString(x_pj + mitad_sec - 0.1*cm, y - 0.35*cm, _fmt_num_f350(data['base']))
        c.drawRightString(x_pj + ancho_seccion - 0.1*cm, y - 0.35*cm, _fmt_num_f350(data['retencion']))

        c.setFillColor(GRIS_CLARO)
        c.rect(x_pn, y - alto_fila, ancho_seccion, alto_fila, fill=1, stroke=1)
        c.setFillColor(black)

        y -= alto_fila

    y -= 0.2*cm
    total_retenciones = total_ret_renta + total_autorret

    def _fila_total(etiqueta, casilla, valor, resaltar=False):
        nonlocal y
        color_fondo = HexColor("#FFF2CC") if resaltar else GRIS_CLARO
        ancho_valor = 1.8*cm
        c.setFillColor(color_fondo)
        c.rect(x_inicio, y - alto_fila, ancho - 3*cm - ancho_valor, alto_fila, fill=1, stroke=1)
        c.setFillColor(black)
        c.setFont("Helvetica-Bold" if resaltar else "Helvetica", 8)
        c.drawString(x_inicio + 0.1*cm, y - 0.32*cm, etiqueta)
        c.setFillColor(color_fondo)
        c.rect(ancho - 1.5*cm - ancho_valor, y - alto_fila, ancho_valor, alto_fila, fill=1, stroke=1)
        c.setFillColor(grey)
        c.setFont("Helvetica", 6)
        c.drawString(ancho - 1.5*cm - ancho_valor + 0.08*cm, y - 0.18*cm, str(casilla))
        c.setFillColor(black)
        c.setFont("Helvetica-Bold", 10)
        c.drawRightString(ancho - 1.6*cm, y - 0.35*cm, _fmt_num_f350(valor))
        y -= alto_fila

    _fila_total("Total retenciones renta y complementario", 130, total_retenciones, resaltar=True)
    iva = aproximar_a_miles(datos.get('total_iva', 0))
    timbre = aproximar_a_miles(datos.get('total_timbre', 0))
    _fila_total("A responsables del impuesto sobre las ventas", 131, iva)
    _fila_total("Practicadas por servicios a no residentes", 132, 0)
    _fila_total("Menos retenciones IVA en exceso o indebidas", 133, 0)
    _fila_total("Total retenciones IVA", 134, iva)
    _fila_total("Retenciones impuesto timbre nacional", 135, timbre)
    total_general = total_retenciones + iva + timbre
    _fila_total("Total retenciones", 136, total_general)
    _fila_total("Sanciones", 137, 0)
    _fila_total("Total retenciones más sanciones", 138, total_general, resaltar=True)

    y -= 0.5*cm
    c.setFont("Helvetica-Oblique", 7)
    c.setFillColor(grey)
    c.drawString(1.5*cm, y, "Generado por BorradorFácil 350 · Este documento es un borrador de referencia")
    c.drawString(1.5*cm, y - 0.35*cm,
                  "La declaración oficial debe presentarse por Muisca (DIAN) con el IFE del contador.")

    c.save()
    return ruta_salida


# ==========================================================
# BASE DE DATOS (SQLite)
# ==========================================================

class Database:
    def __init__(self, db_file=DB_FILE):
        self.db_file = db_file
        self.conn = None
        self.conectar()
        self.crear_tablas()
        self.cargar_datos_iniciales()

    def conectar(self):
        self.conn = sqlite3.connect(self.db_file)
        self.conn.row_factory = sqlite3.Row
        self.conn.execute("PRAGMA foreign_keys = ON")

    def crear_tablas(self):
        cursor = self.conn.cursor()

        cursor.execute("""
            CREATE TABLE IF NOT EXISTS empresas (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                nit TEXT UNIQUE NOT NULL,
                dv TEXT,
                razon_social TEXT NOT NULL,
                tipo_contribuyente TEXT,
                ciiu_principal TEXT,
                es_autorretenedor INTEGER DEFAULT 0,
                tarifa_autorretencion REAL DEFAULT 0,
                exonerado_art_114_1 INTEGER DEFAULT 0,
                direccion TEXT,
                ciudad TEXT,
                representante_legal TEXT,
                email_contacto TEXT,
                estado TEXT DEFAULT 'Activo',
                notas TEXT,
                fecha_creacion TEXT DEFAULT CURRENT_TIMESTAMP
            )
        """)

        cursor.execute("""
            CREATE TABLE IF NOT EXISTS historial_ciiu (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                empresa_id INTEGER,
                ciiu_anterior TEXT,
                ciiu_nuevo TEXT NOT NULL,
                fecha_vigencia_desde TEXT NOT NULL,
                motivo_cambio TEXT,
                numero_radicado_pqr TEXT,
                fecha_creacion TEXT DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (empresa_id) REFERENCES empresas(id)
            )
        """)

        cursor.execute("""
            CREATE TABLE IF NOT EXISTS terceros (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                empresa_id INTEGER,
                nit TEXT NOT NULL,
                nombre_razon_social TEXT NOT NULL,
                tipo_inferido TEXT,
                es_extranjero INTEGER DEFAULT 0,
                es_residente_fiscal TEXT,
                pais_origen TEXT,
                declarante_renta TEXT,
                regimen_iva TEXT,
                notas TEXT,
                UNIQUE(empresa_id, nit),
                FOREIGN KEY (empresa_id) REFERENCES empresas(id)
            )
        """)

        cursor.execute("""
            CREATE TABLE IF NOT EXISTS catalogo_ciiu (
                codigo TEXT PRIMARY KEY,
                actividad_economica TEXT NOT NULL,
                seccion_ciiu TEXT,
                tarifa_autorretencion REAL,
                vigencia_desde TEXT,
                normativa TEXT DEFAULT 'Dec. 0572 de 2025'
            )
        """)

        cursor.execute("""
            CREATE TABLE IF NOT EXISTS uvt_historico (
                año INTEGER PRIMARY KEY,
                valor_uvt_pesos INTEGER NOT NULL,
                resolucion_dian TEXT
            )
        """)

        cursor.execute("""
            CREATE TABLE IF NOT EXISTS declaraciones (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                empresa_id INTEGER NOT NULL,
                año INTEGER NOT NULL,
                mes INTEGER NOT NULL,
                fecha_carga TEXT DEFAULT CURRENT_TIMESTAMP,
                estado TEXT DEFAULT 'Borrador',
                base_autorretencion REAL DEFAULT 0,
                valor_autorretencion REAL DEFAULT 0,
                total_retenciones_renta REAL DEFAULT 0,
                total_declaracion REAL DEFAULT 0,
                ciiu_aplicado TEXT,
                tarifa_aplicada REAL,
                notas TEXT,
                UNIQUE(empresa_id, año, mes),
                FOREIGN KEY (empresa_id) REFERENCES empresas(id)
            )
        """)

        cursor.execute("""
            CREATE TABLE IF NOT EXISTS movimientos_declaracion (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                declaracion_id INTEGER NOT NULL,
                cuenta_puc TEXT NOT NULL,
                nit_tercero TEXT NOT NULL,
                nombre_tercero TEXT,
                tipo_inferido TEXT,
                es_extranjero INTEGER DEFAULT 0,
                base REAL NOT NULL,
                tarifa REAL NOT NULL,
                retencion REAL NOT NULL,
                casilla_destino INTEGER,
                concepto_asignado TEXT,
                estado TEXT DEFAULT 'ok',
                notas TEXT,
                FOREIGN KEY (declaracion_id) REFERENCES declaraciones(id) ON DELETE CASCADE
            )
        """)

        cursor.execute("""
            CREATE TABLE IF NOT EXISTS subcuentas_autorretencion (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                declaracion_id INTEGER NOT NULL,
                codigo_subcuenta TEXT NOT NULL,
                nombre_subcuenta TEXT,
                creditos REAL DEFAULT 0,
                debitos REAL DEFAULT 0,
                FOREIGN KEY (declaracion_id) REFERENCES declaraciones(id) ON DELETE CASCADE
            )
        """)

        self.conn.commit()

    def cargar_datos_iniciales(self):
        cursor = self.conn.cursor()

        # Verificar si ya hay datos
        cursor.execute("SELECT COUNT(*) FROM uvt_historico")
        if cursor.fetchone()[0] > 0:
            return

        # Cargar UVT histórica
        uvts = [
            (2020, 35607, "Res. 000084 de 2019"),
            (2021, 36308, "Res. 000111 de 2020"),
            (2022, 38004, "Res. 000140 de 2021"),
            (2023, 42412, "Res. 001264 de 2022"),
            (2024, 47065, "Res. 000187 de 2023"),
            (2025, 49799, "Res. DIAN 2024"),
            (2026, 52374, "Res. DIAN 2025"),
        ]
        cursor.executemany(
            "INSERT INTO uvt_historico (año, valor_uvt_pesos, resolucion_dian) VALUES (?, ?, ?)",
            uvts
        )

        # Cargar catálogo CIIU con las tarifas del Decreto 0572/2025
        # (Los más usados por PYMES colombianas)
        ciius = [
            ("111", "Cultivo de cereales", "A - Agricultura", 0.0120),
            ("123", "Cultivo de café", "A - Agricultura", 0.0120),
            ("141", "Cría de ganado bovino y bufalino", "A - Agricultura", 0.0120),
            ("510", "Extracción de hulla (carbón de piedra)", "B - Minería", 0.0450),
            ("610", "Extracción de petróleo crudo", "B - Minería", 0.0270),
            ("722", "Extracción de oro y metales preciosos", "B - Minería", 0.0450),
            ("1011", "Procesamiento y conservación de carne", "C - Manufactura", 0.0055),
            ("1040", "Elaboración de productos lácteos", "C - Manufactura", 0.0055),
            ("1081", "Elaboración de productos de panadería", "C - Manufactura", 0.0055),
            ("1084", "Elaboración de comidas y platos preparados", "C - Manufactura", 0.0055),
            ("1101", "Destilación y mezcla de bebidas alcohólicas", "C - Manufactura", 0.0055),
            ("1410", "Confección de prendas de vestir", "C - Manufactura", 0.0055),
            ("1521", "Fabricación de calzado de cuero", "C - Manufactura", 0.0055),
            ("2100", "Fabricación de productos farmacéuticos", "C - Manufactura", 0.0120),
            ("3110", "Fabricación de muebles", "C - Manufactura", 0.0055),
            ("3511", "Generación de energía eléctrica", "D - Servicios Públicos", 0.0450),
            ("3600", "Captación y distribución de agua", "E - Agua", 0.0450),
            ("4111", "Construcción de edificios residenciales", "F - Construcción", 0.0350),
            ("4112", "Construcción de edificios no residenciales", "F - Construcción", 0.0110),
            ("4290", "Construcción de otras obras de ingeniería civil", "F - Construcción", 0.0110),
            ("4511", "Comercio de vehículos automotores nuevos", "G - Comercio", 0.0055),
            ("4631", "Comercio mayor de productos alimenticios", "G - Comercio", 0.0120),
            ("4711", "Comercio minorista no especializado alimentos", "G - Comercio", 0.0055),
            ("4719", "Comercio minorista no especializado otros", "G - Comercio", 0.0055),
            ("4771", "Comercio minorista de prendas de vestir", "G - Comercio", 0.0120),
            ("4921", "Transporte de pasajeros", "H - Transporte", 0.0350),
            ("4923", "Transporte de carga por carretera", "H - Transporte", 0.0350),
            ("5211", "Almacenamiento y depósito", "H - Transporte", 0.0110),
            ("5511", "Alojamiento en hoteles", "I - Alojamiento", 0.0110),
            ("5611", "Expendio a la mesa de comidas preparadas", "I - Comidas", 0.0350),
            ("5612", "Expendio por autoservicio de comidas preparadas", "I - Comidas", 0.0110),
            ("5613", "Expendio de comidas en cafeterías", "I - Comidas", 0.0350),
            ("5630", "Expendio de bebidas alcohólicas", "I - Comidas", 0.0110),
            ("5820", "Edición de programas de informática", "J - Info", 0.0110),
            ("6110", "Telecomunicaciones alámbricas", "J - Info", 0.0220),
            ("6201", "Desarrollo de sistemas informáticos", "J - Info", 0.0110),
            ("6311", "Procesamiento de datos y hosting", "J - Info", 0.0110),
            ("6412", "Bancos comerciales", "K - Financieras", 0.0110),
            ("6511", "Seguros generales", "K - Financieras", 0.0350),
            ("6810", "Actividades inmobiliarias bienes propios", "L - Inmobiliarias", 0.0350),
            ("6910", "Actividades jurídicas", "M - Profesionales", 0.0110),
            ("6920", "Actividades de contabilidad y asesoría tributaria", "M - Profesionales", 0.0110),
            ("7020", "Actividades de consultoría de gestión", "M - Profesionales", 0.0110),
            ("7111", "Actividades de arquitectura", "M - Profesionales", 0.0110),
            ("7112", "Actividades de ingeniería", "M - Profesionales", 0.0110),
            ("7310", "Publicidad", "M - Profesionales", 0.0110),
            ("8010", "Actividades de seguridad privada", "N - Admin", 0.0350),
            ("8610", "Actividades de hospitales y clínicas", "Q - Salud", 0.0350),
            ("8621", "Práctica médica sin internación", "Q - Salud", 0.0110),
            ("8512", "Educación preescolar", "P - Educación", 0.0350),
            ("9200", "Juegos de azar y apuestas", "R - Artísticas", 0.0350),
        ]
        cursor.executemany(
            "INSERT INTO catalogo_ciiu (codigo, actividad_economica, seccion_ciiu, tarifa_autorretencion, vigencia_desde) VALUES (?, ?, ?, ?, '2025-06-01')",
            ciius
        )

        self.conn.commit()

    def cerrar(self):
        if self.conn:
            self.conn.close()


# ==========================================================
# APLICACIÓN PRINCIPAL
# ==========================================================

class BorradorFacilApp:
    def __init__(self, root):
        self.root = root
        self.db = Database()

        # Configurar ventana principal
        self.root.title(f"{APP_NAME} - v{APP_VERSION}")
        self.root.geometry("1100x700")
        self.root.configure(bg=COLOR_BG)

        # Configurar estilos
        self.configurar_estilos()

        # Construir interfaz
        self.construir_header()
        self.construir_navegacion()
        self.construir_contenido()

        # Mostrar pantalla inicial
        self.mostrar_dashboard()

    def configurar_estilos(self):
        style = ttk.Style()
        style.theme_use('clam')

        # Estilo de los botones del menú
        style.configure("Menu.TButton",
                        font=('Arial', 11),
                        padding=10,
                        background=COLOR_BG,
                        foreground=COLOR_TEXT)

        # Estilo de los botones primarios
        style.configure("Primary.TButton",
                        font=('Arial', 10, 'bold'),
                        padding=8,
                        background=COLOR_PRIMARY,
                        foreground='white')

        # Estilo de las tablas
        style.configure("Treeview",
                        rowheight=28,
                        font=('Arial', 10))
        style.configure("Treeview.Heading",
                        font=('Arial', 10, 'bold'),
                        background=COLOR_PRIMARY,
                        foreground='white')

    def construir_header(self):
        header = tk.Frame(self.root, bg=COLOR_PRIMARY, height=60)
        header.pack(fill=tk.X, side=tk.TOP)
        header.pack_propagate(False)

        # Logo / título
        titulo_frame = tk.Frame(header, bg=COLOR_PRIMARY)
        titulo_frame.pack(side=tk.LEFT, padx=20)

        logo = tk.Label(titulo_frame, text="F350", bg='white', fg=COLOR_PRIMARY,
                        font=('Arial', 14, 'bold'), width=4, height=2)
        logo.pack(side=tk.LEFT, pady=8)

        texto = tk.Frame(titulo_frame, bg=COLOR_PRIMARY)
        texto.pack(side=tk.LEFT, padx=10)
        tk.Label(texto, text=APP_NAME, bg=COLOR_PRIMARY, fg='white',
                 font=('Arial', 14, 'bold')).pack(anchor='w')
        tk.Label(texto, text="Borrador de Retefuente — Decreto 0572/2025",
                 bg=COLOR_PRIMARY, fg='#D9E1F2',
                 font=('Arial', 9)).pack(anchor='w')

        # Info de versión
        version_label = tk.Label(header, text=f"v{APP_VERSION}",
                                 bg=COLOR_PRIMARY, fg='#D9E1F2',
                                 font=('Arial', 9))
        version_label.pack(side=tk.RIGHT, padx=20)

    def construir_navegacion(self):
        self.nav_frame = tk.Frame(self.root, bg=COLOR_SECONDARY, width=220)
        self.nav_frame.pack(fill=tk.Y, side=tk.LEFT)
        self.nav_frame.pack_propagate(False)

        tk.Label(self.nav_frame, text="MENÚ",
                 bg=COLOR_SECONDARY, fg=COLOR_PRIMARY,
                 font=('Arial', 10, 'bold')).pack(pady=(20, 10), padx=20, anchor='w')

        botones = [
            ("📊 Dashboard", self.mostrar_dashboard),
            ("🏢 Empresas", self.mostrar_empresas),
            ("👥 Terceros", self.mostrar_terceros),
            ("📋 Declaraciones", self.mostrar_declaraciones),
            ("➕ Nueva Declaración", self.mostrar_nueva_declaracion),
            ("📖 Catálogo CIIU", self.mostrar_ciiu),
            ("🔧 Utilidades NIT", self.mostrar_utilidades_nit),
            ("ℹ️ Ayuda", self.mostrar_ayuda),
        ]

        for texto, comando in botones:
            btn = tk.Button(self.nav_frame, text=texto,
                            bg=COLOR_SECONDARY, fg=COLOR_TEXT,
                            font=('Arial', 10),
                            bd=0, anchor='w', padx=20, pady=10,
                            activebackground=COLOR_PRIMARY,
                            activeforeground='white',
                            command=comando)
            btn.pack(fill=tk.X)

        # Pie del menú
        pie_frame = tk.Frame(self.nav_frame, bg=COLOR_SECONDARY)
        pie_frame.pack(side=tk.BOTTOM, fill=tk.X, padx=20, pady=20)
        tk.Label(pie_frame, text="UVT 2026: $52.374",
                 bg=COLOR_SECONDARY, fg=COLOR_TEXT_SECONDARY,
                 font=('Arial', 9)).pack(anchor='w')

    def construir_contenido(self):
        self.contenido_frame = tk.Frame(self.root, bg=COLOR_BG)
        self.contenido_frame.pack(fill=tk.BOTH, expand=True, side=tk.RIGHT, padx=20, pady=20)

    def limpiar_contenido(self):
        try:
            self.root.unbind_all('<MouseWheel>')
        except Exception:
            pass
        for widget in self.contenido_frame.winfo_children():
            widget.destroy()

    # ==========================================================
    # PANTALLAS
    # ==========================================================

    def mostrar_dashboard(self):
        self.limpiar_contenido()

        tk.Label(self.contenido_frame, text="Dashboard",
                 bg=COLOR_BG, fg=COLOR_PRIMARY,
                 font=('Arial', 18, 'bold')).pack(anchor='w', pady=(0, 10))

        tk.Label(self.contenido_frame,
                 text="Bienvenida al sistema. Aquí verás el resumen de tu actividad.",
                 bg=COLOR_BG, fg=COLOR_TEXT_SECONDARY,
                 font=('Arial', 11)).pack(anchor='w', pady=(0, 20))

        # Tarjetas de métricas
        cards_frame = tk.Frame(self.contenido_frame, bg=COLOR_BG)
        cards_frame.pack(fill=tk.X, pady=10)

        cursor = self.db.conn.cursor()
        cursor.execute("SELECT COUNT(*) FROM empresas WHERE estado='Activo'")
        total_empresas = cursor.fetchone()[0]

        cursor.execute("SELECT COUNT(*) FROM declaraciones")
        total_declaraciones = cursor.fetchone()[0]

        cursor.execute("SELECT COUNT(*) FROM declaraciones WHERE estado='Borrador'")
        total_borradores = cursor.fetchone()[0]

        self.crear_card(cards_frame, "Empresas activas", str(total_empresas), COLOR_SECONDARY)
        self.crear_card(cards_frame, "Declaraciones totales", str(total_declaraciones), COLOR_SUCCESS)
        self.crear_card(cards_frame, "Borradores pendientes", str(total_borradores), COLOR_WARNING)
        self.crear_card(cards_frame, "UVT 2026", "$52.374", COLOR_SECONDARY)

        # Sección de acciones rápidas
        acciones_frame = tk.Frame(self.contenido_frame, bg=COLOR_BG)
        acciones_frame.pack(fill=tk.X, pady=30)

        tk.Label(acciones_frame, text="Acciones rápidas",
                 bg=COLOR_BG, fg=COLOR_PRIMARY,
                 font=('Arial', 14, 'bold')).pack(anchor='w', pady=(0, 15))

        botones_frame = tk.Frame(acciones_frame, bg=COLOR_BG)
        botones_frame.pack(fill=tk.X)

        self.crear_boton_accion(botones_frame, "➕ Registrar empresa",
                                 self.mostrar_nueva_empresa)
        self.crear_boton_accion(botones_frame, "📋 Nueva declaración",
                                 self.mostrar_nueva_declaracion)
        self.crear_boton_accion(botones_frame, "🔧 Validar NIT",
                                 self.mostrar_utilidades_nit)

    def crear_card(self, parent, titulo, valor, color_bg):
        card = tk.Frame(parent, bg=color_bg, padx=20, pady=15, relief=tk.FLAT, bd=0)
        card.pack(side=tk.LEFT, padx=8, fill=tk.X, expand=True)

        tk.Label(card, text=titulo, bg=color_bg, fg=COLOR_TEXT_SECONDARY,
                 font=('Arial', 10)).pack(anchor='w')
        tk.Label(card, text=valor, bg=color_bg, fg=COLOR_PRIMARY,
                 font=('Arial', 20, 'bold')).pack(anchor='w', pady=(5, 0))

    def crear_boton_accion(self, parent, texto, comando):
        btn = tk.Button(parent, text=texto,
                        bg=COLOR_PRIMARY, fg='white',
                        font=('Arial', 11, 'bold'),
                        padx=20, pady=10, bd=0,
                        cursor='hand2',
                        command=comando)
        btn.pack(side=tk.LEFT, padx=5)

    def mostrar_empresas(self):
        self.limpiar_contenido()

        # Header con botón nuevo
        header = tk.Frame(self.contenido_frame, bg=COLOR_BG)
        header.pack(fill=tk.X, pady=(0, 20))

        tk.Label(header, text="Empresas",
                 bg=COLOR_BG, fg=COLOR_PRIMARY,
                 font=('Arial', 18, 'bold')).pack(side=tk.LEFT)

        btn_nuevo = tk.Button(header, text="➕ Nueva empresa",
                              bg=COLOR_PRIMARY, fg='white',
                              font=('Arial', 10, 'bold'),
                              padx=15, pady=8, bd=0, cursor='hand2',
                              command=self.mostrar_nueva_empresa)
        btn_nuevo.pack(side=tk.RIGHT)

        # Tabla de empresas
        tree_frame = tk.Frame(self.contenido_frame, bg=COLOR_BG)
        tree_frame.pack(fill=tk.BOTH, expand=True)

        columnas = ("NIT", "Razón Social", "CIIU", "Autorret.", "Estado")
        self.tree_empresas = ttk.Treeview(tree_frame, columns=columnas, show='headings', height=15)

        for col in columnas:
            self.tree_empresas.heading(col, text=col)
            self.tree_empresas.column(col, width=180)

        scrollbar = ttk.Scrollbar(tree_frame, orient=tk.VERTICAL, command=self.tree_empresas.yview)
        self.tree_empresas.configure(yscrollcommand=scrollbar.set)

        self.tree_empresas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

        # Cargar datos
        cursor = self.db.conn.cursor()
        cursor.execute("SELECT nit, dv, razon_social, ciiu_principal, es_autorretenedor, estado FROM empresas ORDER BY razon_social")
        for row in cursor.fetchall():
            nit_formateado = formato_nit(row['nit'])
            autorret = "Sí" if row['es_autorretenedor'] else "No"
            self.tree_empresas.insert('', tk.END, values=(nit_formateado, row['razon_social'],
                                                           row['ciiu_principal'] or '-',
                                                           autorret, row['estado']))

        # Mensaje si vacío
        if not self.tree_empresas.get_children():
            tk.Label(self.contenido_frame,
                     text="No hay empresas registradas todavía. Haz clic en '+ Nueva empresa' para comenzar.",
                     bg=COLOR_BG, fg=COLOR_TEXT_SECONDARY,
                     font=('Arial', 11, 'italic')).pack(pady=30)

    def mostrar_nueva_empresa(self):
        self.limpiar_contenido()

        tk.Label(self.contenido_frame, text="Nueva empresa",
                 bg=COLOR_BG, fg=COLOR_PRIMARY,
                 font=('Arial', 18, 'bold')).pack(anchor='w', pady=(0, 20))

        form_frame = tk.Frame(self.contenido_frame, bg=COLOR_BG)
        form_frame.pack(fill=tk.X, pady=10)

        # Variables para los campos
        self.entries_empresa = {}

        campos = [
            ("nit", "NIT (sin DV)", "entry"),
            ("razon_social", "Razón Social", "entry"),
            ("tipo_contribuyente", "Tipo Contribuyente", "combo",
             ["Persona Jurídica Ordinaria", "Gran Contribuyente",
              "Régimen Simple", "Persona Natural Comerciante"]),
            ("ciiu_principal", "Código CIIU", "entry"),
            ("direccion", "Dirección", "entry"),
            ("ciudad", "Ciudad", "entry"),
            ("representante_legal", "Representante Legal", "entry"),
            ("email_contacto", "Email de contacto", "entry"),
        ]

        for i, campo in enumerate(campos):
            key, label, tipo, *opciones = campo

            frame_campo = tk.Frame(form_frame, bg=COLOR_BG)
            frame_campo.pack(fill=tk.X, pady=6)

            tk.Label(frame_campo, text=label + ":",
                     bg=COLOR_BG, font=('Arial', 10),
                     width=20, anchor='w').pack(side=tk.LEFT)

            if tipo == "entry":
                entry = tk.Entry(frame_campo, font=('Arial', 10), width=40, relief=tk.SOLID, bd=1)
                entry.pack(side=tk.LEFT, padx=5)
                self.entries_empresa[key] = entry
            elif tipo == "combo":
                combo = ttk.Combobox(frame_campo, font=('Arial', 10), width=38,
                                     values=opciones[0])
                combo.pack(side=tk.LEFT, padx=5)
                self.entries_empresa[key] = combo

        # Checkbox autorretenedor
        self.var_autorretenedor = tk.IntVar()
        check_frame = tk.Frame(form_frame, bg=COLOR_BG)
        check_frame.pack(fill=tk.X, pady=6)
        tk.Label(check_frame, text="", bg=COLOR_BG, width=20).pack(side=tk.LEFT)
        tk.Checkbutton(check_frame, text="Es autorretenedora (Art. 114-1 ET)",
                       variable=self.var_autorretenedor,
                       bg=COLOR_BG, font=('Arial', 10)).pack(side=tk.LEFT)

        # Botones
        btn_frame = tk.Frame(self.contenido_frame, bg=COLOR_BG)
        btn_frame.pack(fill=tk.X, pady=20)

        tk.Button(btn_frame, text="Guardar empresa",
                  bg=COLOR_PRIMARY, fg='white',
                  font=('Arial', 11, 'bold'),
                  padx=20, pady=10, bd=0, cursor='hand2',
                  command=self.guardar_empresa).pack(side=tk.LEFT, padx=5)

        tk.Button(btn_frame, text="Cancelar",
                  bg='#CCCCCC', fg=COLOR_TEXT,
                  font=('Arial', 11),
                  padx=20, pady=10, bd=0, cursor='hand2',
                  command=self.mostrar_empresas).pack(side=tk.LEFT, padx=5)

        # Botón cargar empresa de ejemplo (SILLA TRES)
        tk.Button(btn_frame, text="📌 Cargar ejemplo (SILLA TRES)",
                  bg=COLOR_WARNING, fg=COLOR_TEXT,
                  font=('Arial', 10),
                  padx=15, pady=10, bd=0, cursor='hand2',
                  command=self.cargar_ejemplo_silla_tres).pack(side=tk.RIGHT, padx=5)

    def cargar_ejemplo_silla_tres(self):
        """Precarga los datos de SILLA TRES para pruebas rápidas"""
        self.entries_empresa['nit'].delete(0, tk.END)
        self.entries_empresa['nit'].insert(0, "900451388")

        self.entries_empresa['razon_social'].delete(0, tk.END)
        self.entries_empresa['razon_social'].insert(0, "SILLA TRES S.A.S")

        self.entries_empresa['tipo_contribuyente'].set("Persona Jurídica Ordinaria")

        self.entries_empresa['ciiu_principal'].delete(0, tk.END)
        self.entries_empresa['ciiu_principal'].insert(0, "5612")

        self.entries_empresa['ciudad'].delete(0, tk.END)
        self.entries_empresa['ciudad'].insert(0, "Medellín")

        self.entries_empresa['email_contacto'].delete(0, tk.END)
        self.entries_empresa['email_contacto'].insert(0, "contacto@sillatres.com")

        self.var_autorretenedor.set(1)

        messagebox.showinfo("Datos de ejemplo cargados",
                            "Se precargaron los datos de SILLA TRES S.A.S.\n"
                            "Revisa los campos y haz clic en 'Guardar empresa'.")

    def guardar_empresa(self):
        try:
            nit = self.entries_empresa['nit'].get().strip()
            razon = self.entries_empresa['razon_social'].get().strip()

            if not nit or not razon:
                messagebox.showerror("Error", "NIT y Razón Social son obligatorios")
                return

            # Validar NIT numérico
            nit_limpio = ''.join(c for c in nit if c.isdigit())
            if not nit_limpio:
                messagebox.showerror("Error", "El NIT debe contener números")
                return

            dv = calcular_dv(nit_limpio)

            # Obtener tarifa desde CIIU
            ciiu = self.entries_empresa['ciiu_principal'].get().strip()
            tarifa_autorret = 0
            if ciiu:
                cursor = self.db.conn.cursor()
                cursor.execute("SELECT tarifa_autorretencion FROM catalogo_ciiu WHERE codigo=?", (ciiu,))
                row = cursor.fetchone()
                if row:
                    tarifa_autorret = row['tarifa_autorretencion']

            cursor = self.db.conn.cursor()
            cursor.execute("""
                INSERT INTO empresas (nit, dv, razon_social, tipo_contribuyente, ciiu_principal,
                                      es_autorretenedor, tarifa_autorretencion, direccion, ciudad,
                                      representante_legal, email_contacto)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                nit_limpio, dv, razon,
                self.entries_empresa['tipo_contribuyente'].get(),
                ciiu,
                self.var_autorretenedor.get(),
                tarifa_autorret,
                self.entries_empresa['direccion'].get(),
                self.entries_empresa['ciudad'].get(),
                self.entries_empresa['representante_legal'].get(),
                self.entries_empresa['email_contacto'].get(),
            ))
            self.db.conn.commit()

            messagebox.showinfo("Éxito",
                                f"Empresa '{razon}' registrada correctamente.\n\n"
                                f"NIT: {formato_nit(nit_limpio)}\n"
                                f"Tarifa autorretención: {tarifa_autorret*100:.2f}%")
            self.mostrar_empresas()

        except sqlite3.IntegrityError:
            messagebox.showerror("Error", "Ya existe una empresa registrada con ese NIT")
        except Exception as e:
            messagebox.showerror("Error", f"Error al guardar: {str(e)}")

    def mostrar_utilidades_nit(self):
        self.limpiar_contenido()

        tk.Label(self.contenido_frame, text="Utilidades de NIT",
                 bg=COLOR_BG, fg=COLOR_PRIMARY,
                 font=('Arial', 18, 'bold')).pack(anchor='w', pady=(0, 10))

        tk.Label(self.contenido_frame,
                 text="Clasifica automáticamente un NIT y calcula su dígito de verificación.",
                 bg=COLOR_BG, fg=COLOR_TEXT_SECONDARY,
                 font=('Arial', 11)).pack(anchor='w', pady=(0, 20))

        # Input
        input_frame = tk.Frame(self.contenido_frame, bg=COLOR_BG)
        input_frame.pack(fill=tk.X, pady=10)

        tk.Label(input_frame, text="NIT a consultar:",
                 bg=COLOR_BG, font=('Arial', 11)).pack(side=tk.LEFT, padx=(0, 10))

        self.entry_nit_utilidad = tk.Entry(input_frame, font=('Arial', 12), width=20,
                                            relief=tk.SOLID, bd=1)
        self.entry_nit_utilidad.pack(side=tk.LEFT, padx=5)
        self.entry_nit_utilidad.bind('<KeyRelease>', lambda e: self.analizar_nit())

        tk.Button(input_frame, text="Analizar",
                  bg=COLOR_PRIMARY, fg='white',
                  font=('Arial', 10, 'bold'),
                  padx=15, pady=5, bd=0, cursor='hand2',
                  command=self.analizar_nit).pack(side=tk.LEFT, padx=10)

        # Frame de resultado
        self.resultado_nit_frame = tk.Frame(self.contenido_frame, bg=COLOR_BG)
        self.resultado_nit_frame.pack(fill=tk.X, pady=20)

        # Botones de ejemplos
        ejemplos_frame = tk.Frame(self.contenido_frame, bg=COLOR_BG)
        ejemplos_frame.pack(fill=tk.X, pady=20)

        tk.Label(ejemplos_frame, text="Prueba con estos ejemplos:",
                 bg=COLOR_BG, font=('Arial', 10, 'bold')).pack(anchor='w', pady=(0, 10))

        ejemplos = [
            ("16285204", "PN cédula antigua"),
            ("900451388", "PJ empresa"),
            ("1037653519", "PN cédula moderna"),
            ("650123456", "PN extranjera"),
        ]

        btns_frame = tk.Frame(ejemplos_frame, bg=COLOR_BG)
        btns_frame.pack(anchor='w')

        for nit, desc in ejemplos:
            btn = tk.Button(btns_frame, text=f"{nit}\n{desc}",
                            bg=COLOR_SECONDARY, fg=COLOR_TEXT,
                            font=('Arial', 9),
                            padx=10, pady=5, bd=0, cursor='hand2',
                            command=lambda n=nit: self.probar_nit_ejemplo(n))
            btn.pack(side=tk.LEFT, padx=5)

        # Tabla de rangos
        tabla_frame = tk.Frame(self.contenido_frame, bg=COLOR_BG)
        tabla_frame.pack(fill=tk.X, pady=20)

        tk.Label(tabla_frame, text="Rangos según regla DIAN",
                 bg=COLOR_BG, fg=COLOR_PRIMARY,
                 font=('Arial', 12, 'bold')).pack(anchor='w', pady=(0, 10))

        columnas = ("Rango", "Tipo inferido", "Descripción")
        tree = ttk.Treeview(tabla_frame, columns=columnas, show='headings', height=4)
        for col in columnas:
            tree.heading(col, text=col)
            tree.column(col, width=250)

        rangos = [
            ("10.000 - 99.999.999", "Persona Natural", "Cédula ciudadanía antigua"),
            ("600.000.000 - 799.999.999", "PN Extranjera", "NIT DIAN para extranjeros"),
            ("800.000.000 - 999.999.999", "Persona Jurídica", "Empresas y sociedades"),
            ("1.000M - 1.999.999.999", "Persona Natural", "Cédula ciudadanía moderna"),
        ]
        for r in rangos:
            tree.insert('', tk.END, values=r)
        tree.pack(fill=tk.X)

    def probar_nit_ejemplo(self, nit):
        self.entry_nit_utilidad.delete(0, tk.END)
        self.entry_nit_utilidad.insert(0, nit)
        self.analizar_nit()

    def analizar_nit(self):
        for widget in self.resultado_nit_frame.winfo_children():
            widget.destroy()

        nit = self.entry_nit_utilidad.get().strip()
        if not nit:
            return

        tipo, es_extranjero, es_valido, rango = inferir_tipo_persona(nit)
        dv = calcular_dv(nit) if es_valido else ""

        if not es_valido:
            color = COLOR_DANGER
            icono = "⚠️"
        elif es_extranjero:
            color = COLOR_WARNING
            icono = "🌍"
        else:
            color = COLOR_SUCCESS
            icono = "✅"

        resultado_card = tk.Frame(self.resultado_nit_frame, bg=color, padx=20, pady=20)
        resultado_card.pack(fill=tk.X)

        tk.Label(resultado_card, text=f"{icono} {tipo}",
                 bg=color, font=('Arial', 16, 'bold')).pack(anchor='w')

        tk.Label(resultado_card, text=f"Rango aplicado: {rango}",
                 bg=color, font=('Arial', 11)).pack(anchor='w', pady=5)

        if es_valido:
            nit_formateado = formato_nit(nit)
            tk.Label(resultado_card, text=f"NIT formateado: {nit_formateado}",
                     bg=color, font=('Arial', 11)).pack(anchor='w')
            tk.Label(resultado_card, text=f"Dígito de verificación: {dv}",
                     bg=color, font=('Arial', 11)).pack(anchor='w')

        if es_extranjero:
            tk.Label(resultado_card,
                     text="⚠️ ALERTA: Este NIT corresponde a una persona extranjera. "
                          "Debes confirmar la residencia fiscal antes de procesar movimientos, "
                          "ya que afecta las casillas del Formulario 350 (domésticas vs pagos al exterior, Art. 408 ET).",
                     bg=color, font=('Arial', 10, 'italic'),
                     wraplength=700, justify='left').pack(anchor='w', pady=(10, 0))

    def mostrar_ciiu(self):
        self.limpiar_contenido()

        tk.Label(self.contenido_frame, text="Catálogo CIIU",
                 bg=COLOR_BG, fg=COLOR_PRIMARY,
                 font=('Arial', 18, 'bold')).pack(anchor='w', pady=(0, 10))

        tk.Label(self.contenido_frame,
                 text="Tarifas de autorretención especial según Decreto 0572 de 2025 (vigente desde junio 2025).",
                 bg=COLOR_BG, fg=COLOR_TEXT_SECONDARY,
                 font=('Arial', 11)).pack(anchor='w', pady=(0, 20))

        # Buscador
        search_frame = tk.Frame(self.contenido_frame, bg=COLOR_BG)
        search_frame.pack(fill=tk.X, pady=10)

        tk.Label(search_frame, text="Buscar:",
                 bg=COLOR_BG, font=('Arial', 10)).pack(side=tk.LEFT, padx=5)

        self.entry_buscar_ciiu = tk.Entry(search_frame, font=('Arial', 10), width=30,
                                           relief=tk.SOLID, bd=1)
        self.entry_buscar_ciiu.pack(side=tk.LEFT, padx=5)
        self.entry_buscar_ciiu.bind('<KeyRelease>', lambda e: self.filtrar_ciiu())

        # Tabla
        tree_frame = tk.Frame(self.contenido_frame, bg=COLOR_BG)
        tree_frame.pack(fill=tk.BOTH, expand=True, pady=10)

        columnas = ("Código", "Actividad Económica", "Sección", "Tarifa")
        self.tree_ciiu = ttk.Treeview(tree_frame, columns=columnas, show='headings', height=20)

        self.tree_ciiu.heading("Código", text="Código")
        self.tree_ciiu.column("Código", width=80)
        self.tree_ciiu.heading("Actividad Económica", text="Actividad Económica")
        self.tree_ciiu.column("Actividad Económica", width=400)
        self.tree_ciiu.heading("Sección", text="Sección")
        self.tree_ciiu.column("Sección", width=180)
        self.tree_ciiu.heading("Tarifa", text="Tarifa")
        self.tree_ciiu.column("Tarifa", width=80)

        scrollbar = ttk.Scrollbar(tree_frame, orient=tk.VERTICAL, command=self.tree_ciiu.yview)
        self.tree_ciiu.configure(yscrollcommand=scrollbar.set)

        self.tree_ciiu.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

        self.cargar_ciiu_tabla()

    def cargar_ciiu_tabla(self, filtro=""):
        for item in self.tree_ciiu.get_children():
            self.tree_ciiu.delete(item)

        cursor = self.db.conn.cursor()
        if filtro:
            cursor.execute("""
                SELECT codigo, actividad_economica, seccion_ciiu, tarifa_autorretencion
                FROM catalogo_ciiu
                WHERE codigo LIKE ? OR actividad_economica LIKE ?
                ORDER BY codigo
            """, (f'%{filtro}%', f'%{filtro}%'))
        else:
            cursor.execute("""
                SELECT codigo, actividad_economica, seccion_ciiu, tarifa_autorretencion
                FROM catalogo_ciiu
                ORDER BY codigo
            """)

        for row in cursor.fetchall():
            tarifa_str = f"{row['tarifa_autorretencion']*100:.2f}%"
            self.tree_ciiu.insert('', tk.END, values=(
                row['codigo'],
                row['actividad_economica'],
                row['seccion_ciiu'],
                tarifa_str
            ))

    def filtrar_ciiu(self):
        filtro = self.entry_buscar_ciiu.get().strip()
        self.cargar_ciiu_tabla(filtro)

    def mostrar_terceros(self):
        self.limpiar_contenido()
        tk.Label(self.contenido_frame, text="Terceros",
                 bg=COLOR_BG, fg=COLOR_PRIMARY,
                 font=('Arial', 18, 'bold')).pack(anchor='w', pady=(0, 10))

        tk.Label(self.contenido_frame,
                 text="Funcionalidad disponible en la versión completa (v2.0).\n"
                      "Por ahora, los terceros se registran automáticamente al ingresar movimientos de una declaración.",
                 bg=COLOR_BG, fg=COLOR_TEXT_SECONDARY,
                 font=('Arial', 11), justify='left').pack(anchor='w', pady=20)

    def mostrar_declaraciones(self):
        self.limpiar_contenido()
        tk.Label(self.contenido_frame, text="Declaraciones",
                 bg=COLOR_BG, fg=COLOR_PRIMARY,
                 font=('Arial', 18, 'bold')).pack(anchor='w', pady=(0, 20))

        # Tabla de declaraciones
        tree_frame = tk.Frame(self.contenido_frame, bg=COLOR_BG)
        tree_frame.pack(fill=tk.BOTH, expand=True)

        columnas = ("Empresa", "Período", "Retenciones", "Autorret.", "Total", "Estado")
        self.tree_decl = ttk.Treeview(tree_frame, columns=columnas, show='headings', height=15)

        for col in columnas:
            self.tree_decl.heading(col, text=col)
            self.tree_decl.column(col, width=150)

        self.tree_decl.pack(fill=tk.BOTH, expand=True)

        self.tree_decl.bind('<Double-1>', self._abrir_declaracion_existente)

        cursor = self.db.conn.cursor()
        cursor.execute("""
            SELECT d.*, e.razon_social
            FROM declaraciones d
            JOIN empresas e ON d.empresa_id = e.id
            ORDER BY d.año DESC, d.mes DESC
        """)

        meses = ['', 'Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio',
                 'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre']

        for row in cursor.fetchall():
            self.tree_decl.insert('', tk.END, iid=str(row['id']), values=(
                row['razon_social'],
                f"{meses[row['mes']]} {row['año']}",
                formato_moneda(row['total_retenciones_renta']),
                formato_moneda(row['valor_autorretencion']),
                formato_moneda(row['total_declaracion']),
                row['estado']
            ))

        if not self.tree_decl.get_children():
            tk.Label(self.contenido_frame,
                     text="No hay declaraciones procesadas. Crea una nueva desde el menú.\n\n"
                          "Tip: una vez crees declaraciones, haz doble clic sobre ellas aquí para reabrirlas.",
                     bg=COLOR_BG, fg=COLOR_TEXT_SECONDARY,
                     font=('Arial', 11, 'italic')).pack(pady=30)
        else:
            tk.Label(self.contenido_frame,
                     text="💡 Doble clic sobre una declaración para abrirla y seguir editándola",
                     bg=COLOR_BG, fg=COLOR_TEXT_SECONDARY,
                     font=('Arial', 9, 'italic')).pack(anchor='w', pady=(10, 0))

    def _abrir_declaracion_existente(self, event):
        item = self.tree_decl.selection()
        if not item:
            return
        decl_id = int(item[0])
        self.mostrar_ingreso_movimientos(decl_id)

    def mostrar_nueva_declaracion(self):
        self.limpiar_contenido()

        tk.Label(self.contenido_frame, text="Nueva Declaración",
                 bg=COLOR_BG, fg=COLOR_PRIMARY,
                 font=('Arial', 18, 'bold')).pack(anchor='w', pady=(0, 10))

        tk.Label(self.contenido_frame,
                 text="Selecciona la empresa y el período para iniciar.",
                 bg=COLOR_BG, fg=COLOR_TEXT_SECONDARY,
                 font=('Arial', 11)).pack(anchor='w', pady=(0, 20))

        # Verificar si hay empresas
        cursor = self.db.conn.cursor()
        cursor.execute("SELECT id, nit, razon_social FROM empresas WHERE estado='Activo' ORDER BY razon_social")
        empresas = cursor.fetchall()

        if not empresas:
            aviso = tk.Frame(self.contenido_frame, bg=COLOR_WARNING, padx=20, pady=15)
            aviso.pack(fill=tk.X, pady=10)
            tk.Label(aviso,
                     text="⚠️ No hay empresas registradas.\n"
                          "Primero debes registrar al menos una empresa antes de crear una declaración.",
                     bg=COLOR_WARNING, font=('Arial', 11), justify='left').pack()

            tk.Button(self.contenido_frame, text="➕ Registrar empresa",
                      bg=COLOR_PRIMARY, fg='white',
                      font=('Arial', 11, 'bold'),
                      padx=20, pady=10, bd=0, cursor='hand2',
                      command=self.mostrar_nueva_empresa).pack(pady=10)
            return

        form_frame = tk.Frame(self.contenido_frame, bg=COLOR_BG)
        form_frame.pack(fill=tk.X, pady=10)

        # Selector empresa
        f1 = tk.Frame(form_frame, bg=COLOR_BG)
        f1.pack(fill=tk.X, pady=8)
        tk.Label(f1, text="Empresa:", bg=COLOR_BG, font=('Arial', 11),
                 width=15, anchor='w').pack(side=tk.LEFT)

        self.empresa_seleccionada = ttk.Combobox(f1, font=('Arial', 10), width=50, state='readonly')
        self.empresas_lista = [(e['id'], f"{e['razon_social']} - NIT {formato_nit(e['nit'])}") for e in empresas]
        self.empresa_seleccionada['values'] = [e[1] for e in self.empresas_lista]
        self.empresa_seleccionada.pack(side=tk.LEFT, padx=5)

        # Selector año
        f2 = tk.Frame(form_frame, bg=COLOR_BG)
        f2.pack(fill=tk.X, pady=8)
        tk.Label(f2, text="Año:", bg=COLOR_BG, font=('Arial', 11),
                 width=15, anchor='w').pack(side=tk.LEFT)

        self.año_seleccionado = ttk.Combobox(f2, font=('Arial', 10), width=10, state='readonly',
                                              values=[2024, 2025, 2026])
        self.año_seleccionado.set(2026)
        self.año_seleccionado.pack(side=tk.LEFT, padx=5)

        # Selector mes
        f3 = tk.Frame(form_frame, bg=COLOR_BG)
        f3.pack(fill=tk.X, pady=8)
        tk.Label(f3, text="Mes:", bg=COLOR_BG, font=('Arial', 11),
                 width=15, anchor='w').pack(side=tk.LEFT)

        meses = ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio',
                 'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre']
        self.mes_seleccionado = ttk.Combobox(f3, font=('Arial', 10), width=15, state='readonly',
                                              values=meses)
        self.mes_seleccionado.set('Marzo')
        self.mes_seleccionado.pack(side=tk.LEFT, padx=5)

        # Nota informativa
        nota_frame = tk.Frame(self.contenido_frame, bg=COLOR_SECONDARY, padx=15, pady=15)
        nota_frame.pack(fill=tk.X, pady=20)
        tk.Label(nota_frame,
                 text="ℹ️ En la siguiente pantalla podrás ingresar manualmente los movimientos del auxiliar "
                      "de retefuente y las subcuentas de la cuenta 4 para el cálculo de autorretención. "
                      "La app aplicará automáticamente la regla del NIT, validará tarifas y generará el borrador.",
                 bg=COLOR_SECONDARY, font=('Arial', 10, 'italic'),
                 wraplength=700, justify='left').pack()

        # Botones
        btn_frame = tk.Frame(self.contenido_frame, bg=COLOR_BG)
        btn_frame.pack(fill=tk.X, pady=20)

        tk.Button(btn_frame, text="Continuar →",
                  bg=COLOR_PRIMARY, fg='white',
                  font=('Arial', 11, 'bold'),
                  padx=20, pady=10, bd=0, cursor='hand2',
                  command=self.iniciar_declaracion).pack(side=tk.LEFT, padx=5)

        tk.Button(btn_frame, text="Cancelar",
                  bg='#CCCCCC', fg=COLOR_TEXT,
                  font=('Arial', 11),
                  padx=20, pady=10, bd=0, cursor='hand2',
                  command=self.mostrar_dashboard).pack(side=tk.LEFT, padx=5)

    def iniciar_declaracion(self):
        if not self.empresa_seleccionada.get():
            messagebox.showerror("Error", "Selecciona una empresa")
            return
        if not self.año_seleccionado.get() or not self.mes_seleccionado.get():
            messagebox.showerror("Error", "Selecciona año y mes")
            return

        idx = self.empresa_seleccionada.current()
        empresa_id = self.empresas_lista[idx][0]

        meses = ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio',
                 'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre']
        mes_num = meses.index(self.mes_seleccionado.get()) + 1
        año = int(self.año_seleccionado.get())

        cursor = self.db.conn.cursor()
        cursor.execute("SELECT id FROM declaraciones WHERE empresa_id=? AND año=? AND mes=?",
                       (empresa_id, año, mes_num))
        existente = cursor.fetchone()

        if existente:
            resp = messagebox.askyesno(
                "Declaración existente",
                f"Ya existe una declaración para {self.mes_seleccionado.get()} {año}.\n\n"
                "¿Deseas abrirla y continuar editándola?"
            )
            if resp:
                self.mostrar_ingreso_movimientos(existente['id'])
            return

        cursor.execute("""
            INSERT INTO declaraciones (empresa_id, año, mes, estado)
            VALUES (?, ?, ?, 'Borrador')
        """, (empresa_id, año, mes_num))
        decl_id = cursor.lastrowid
        self.db.conn.commit()

        self.mostrar_ingreso_movimientos(decl_id)

    # ==========================================================
    # MÓDULO DE DECLARACIÓN - OPCIÓN A (Ficha de diligenciamiento)
    # ==========================================================

    def mostrar_ingreso_movimientos(self, decl_id):
        """Pantalla principal: carga automática desde PDFs de Contai."""
        self.limpiar_contenido()
        self.decl_actual_id = decl_id

        cursor = self.db.conn.cursor()
        cursor.execute("""
            SELECT d.*, e.razon_social, e.nit, e.ciiu_principal, e.tarifa_autorretencion,
                   e.es_autorretenedor
            FROM declaraciones d JOIN empresas e ON d.empresa_id = e.id
            WHERE d.id = ?
        """, (decl_id,))
        decl = cursor.fetchone()
        self.decl_empresa = dict(decl)

        meses = ['', 'Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio',
                 'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre']

        header = tk.Frame(self.contenido_frame, bg=COLOR_BG)
        header.pack(fill=tk.X, pady=(0, 15))
        tk.Label(header, text=f"Declaración — {meses[decl['mes']]} {decl['año']}",
                 bg=COLOR_BG, fg=COLOR_PRIMARY,
                 font=('Arial', 18, 'bold')).pack(anchor='w')
        tk.Label(header,
                 text=f"{decl['razon_social']} · NIT {formato_nit(decl['nit'])} · CIIU {decl['ciiu_principal']} · Autorret {decl['tarifa_autorretencion']*100:.2f}%",
                 bg=COLOR_BG, fg=COLOR_TEXT_SECONDARY,
                 font=('Arial', 10)).pack(anchor='w')

        instr = tk.Frame(self.contenido_frame, bg=COLOR_SUCCESS, padx=15, pady=12)
        instr.pack(fill=tk.X, pady=(0, 15))
        tk.Label(instr,
                 text="📂 Carga los 2 PDFs de Contai y la app calculará todo automáticamente.\n\n"
                      "1) Reporte 'Análisis de % de Retención e IVA - Resumido'\n"
                      "2) Balance de Prueba por Cuenta\n\n"
                      "La app extraerá los movimientos, clasificará los NITs, calculará la "
                      "autorretención sobre la cuenta 4 y generará la Ficha de Diligenciamiento.",
                 bg=COLOR_SUCCESS, font=('Arial', 10),
                 wraplength=700, justify='left').pack(anchor='w')

        cards_frame = tk.Frame(self.contenido_frame, bg=COLOR_BG)
        cards_frame.pack(fill=tk.X, pady=5)

        self.card_aux = self._crear_card_carga(
            cards_frame,
            titulo="1. Auxiliar de Retefuente",
            descripcion="Análisis de % de Retención (PDF)",
            estado_attr='_aux_cargado',
            comando=self._cargar_auxiliar_pdf
        )
        self.card_aux.pack(side=tk.LEFT, padx=5, fill=tk.BOTH, expand=True)

        self.card_bal = self._crear_card_carga(
            cards_frame,
            titulo="2. Balance de Prueba",
            descripcion="Balance por Cuenta (PDF)",
            estado_attr='_bal_cargado',
            comando=self._cargar_balance_pdf
        )
        self.card_bal.pack(side=tk.LEFT, padx=5, fill=tk.BOTH, expand=True)

        self._datos_auxiliar = None
        self._datos_balance = None
        self._aux_cargado = False
        self._bal_cargado = False

        btns_frame = tk.Frame(self.contenido_frame, bg=COLOR_BG)
        btns_frame.pack(side=tk.BOTTOM, fill=tk.X, pady=10)

        self.btn_procesar = tk.Button(btns_frame, text="⚙️  Procesar y generar borrador →",
                                       bg=COLOR_PRIMARY, fg='white',
                                       font=('Arial', 11, 'bold'),
                                       padx=20, pady=10, bd=0,
                                       state='disabled',
                                       command=self._procesar_archivos)
        self.btn_procesar.pack(side=tk.LEFT, padx=5)

        tk.Button(btns_frame, text="✏️ Ingreso manual (respaldo)",
                  bg='#CCCCCC', fg=COLOR_TEXT,
                  font=('Arial', 10), padx=15, pady=10, bd=0,
                  cursor='hand2',
                  command=lambda: self.mostrar_ingreso_manual(decl_id)).pack(side=tk.LEFT, padx=5)

        tk.Button(btns_frame, text="← Volver",
                  bg='#CCCCCC', fg=COLOR_TEXT,
                  font=('Arial', 10), padx=15, pady=10, bd=0,
                  cursor='hand2',
                  command=self.mostrar_declaraciones).pack(side=tk.RIGHT, padx=5)

        resumen_container = tk.Frame(self.contenido_frame, bg=COLOR_BG)
        resumen_container.pack(fill=tk.BOTH, expand=True, pady=15)

        self._resumen_canvas = tk.Canvas(resumen_container, bg=COLOR_BG,
                                          highlightthickness=0)
        scrollbar_resumen = ttk.Scrollbar(resumen_container, orient='vertical',
                                           command=self._resumen_canvas.yview)
        self._resumen_canvas.configure(yscrollcommand=scrollbar_resumen.set)

        self._resumen_canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar_resumen.pack(side=tk.RIGHT, fill=tk.Y)

        self.resumen_frame = tk.Frame(self._resumen_canvas, bg=COLOR_BG)
        self._resumen_canvas_window = self._resumen_canvas.create_window(
            (0, 0), window=self.resumen_frame, anchor='nw'
        )

        def _ajustar_scroll(event=None):
            self._resumen_canvas.configure(scrollregion=self._resumen_canvas.bbox("all"))
            ancho_canvas = self._resumen_canvas.winfo_width()
            self._resumen_canvas.itemconfig(self._resumen_canvas_window, width=ancho_canvas)

        self.resumen_frame.bind('<Configure>', _ajustar_scroll)
        self._resumen_canvas.bind('<Configure>', _ajustar_scroll)

        def _on_mousewheel(event):
            self._resumen_canvas.yview_scroll(int(-1 * (event.delta / 120)), "units")
        self._resumen_canvas.bind_all('<MouseWheel>', _on_mousewheel)

        if not PDF_DISPONIBLE:
            alerta = tk.Frame(self.contenido_frame, bg=COLOR_DANGER, padx=15, pady=10)
            alerta.pack(fill=tk.X, pady=10)
            tk.Label(alerta,
                     text="⚠️  pdfplumber no está instalado. Ejecuta en CMD:\n"
                          "pip install pdfplumber",
                     bg=COLOR_DANGER, font=('Arial', 10, 'bold'),
                     justify='left').pack(anchor='w')

    def _crear_card_carga(self, parent, titulo, descripcion, estado_attr, comando):
        card = tk.Frame(parent, bg=COLOR_SECONDARY, padx=15, pady=12, relief=tk.FLAT, bd=0,
                        highlightbackground=COLOR_PRIMARY, highlightthickness=1)
        tk.Label(card, text=titulo, bg=COLOR_SECONDARY, fg=COLOR_PRIMARY,
                 font=('Arial', 11, 'bold')).pack(anchor='w')
        tk.Label(card, text=descripcion, bg=COLOR_SECONDARY, fg=COLOR_TEXT_SECONDARY,
                 font=('Arial', 9)).pack(anchor='w', pady=(2, 8))
        estado_label = tk.Label(card, text="Sin cargar", bg=COLOR_SECONDARY,
                                 fg=COLOR_TEXT_SECONDARY, font=('Arial', 9, 'italic'))
        estado_label.pack(anchor='w', pady=(0, 8))
        boton = tk.Button(card, text="📂 Seleccionar PDF",
                          bg=COLOR_PRIMARY, fg='white',
                          font=('Arial', 10, 'bold'),
                          padx=15, pady=6, bd=0, cursor='hand2',
                          command=comando)
        boton.pack(anchor='w')
        card._estado_label = estado_label
        card._boton = boton
        return card

    def _cargar_auxiliar_pdf(self):
        if not PDF_DISPONIBLE:
            messagebox.showerror("Error", "pdfplumber no está instalado")
            return
        ruta = filedialog.askopenfilename(
            title="Selecciona el Auxiliar de Retefuente (PDF)",
            filetypes=[("PDF", "*.pdf")]
        )
        if not ruta:
            return
        try:
            datos = parsear_auxiliar_contai(ruta)
            if not datos['movimientos']:
                messagebox.showwarning(
                    "Sin movimientos",
                    "No se detectaron movimientos en el PDF.\n\n"
                    "Verifica que sea el reporte 'Análisis de % de Retención e IVA - Resumido' de Contai."
                )
                return
            self._datos_auxiliar = datos
            self._aux_cargado = True
            n = len(datos['movimientos'])
            total_ret = sum(m['retencion'] for m in datos['movimientos'])
            self.card_aux._estado_label.config(
                text=f"✓ {n} movimientos · ${total_ret:,.0f}".replace(',', '.'),
                fg=COLOR_PRIMARY
            )
            self._actualizar_boton_procesar()
            self._mostrar_resumen_previo()
        except Exception as e:
            messagebox.showerror("Error al leer PDF",
                                  f"No se pudo procesar el archivo:\n\n{e}\n\n"
                                  "Verifica que sea el PDF correcto de Contai.")

    def _cargar_balance_pdf(self):
        if not PDF_DISPONIBLE:
            messagebox.showerror("Error", "pdfplumber no está instalado")
            return
        ruta = filedialog.askopenfilename(
            title="Selecciona el Balance de Prueba (PDF)",
            filetypes=[("PDF", "*.pdf")]
        )
        if not ruta:
            return
        try:
            datos = parsear_balance_contai(ruta)
            if not datos['cuentas']:
                messagebox.showwarning(
                    "Sin cuentas",
                    "No se detectaron cuentas en el PDF.\n\n"
                    "Verifica que sea el Balance de Prueba por Cuenta de Contai."
                )
                return
            self._datos_balance = datos
            self._bal_cargado = True
            tarifa = self.decl_empresa['tarifa_autorretencion'] * 100
            auto = calcular_autorretencion_cuenta_4(datos, tarifa)
            if auto:
                self.card_bal._estado_label.config(
                    text=f"✓ Base: ${auto['ingresos_netos']:,.0f}".replace(',', '.'),
                    fg=COLOR_PRIMARY
                )
            self._actualizar_boton_procesar()
            self._mostrar_resumen_previo()
        except Exception as e:
            messagebox.showerror("Error al leer PDF",
                                  f"No se pudo procesar el archivo:\n\n{e}")

    def _actualizar_boton_procesar(self):
        if self._aux_cargado or self._bal_cargado:
            self.btn_procesar.config(state='normal')
        else:
            self.btn_procesar.config(state='disabled')

    def _mostrar_resumen_previo(self):
        for w in self.resumen_frame.winfo_children():
            w.destroy()

        if not (self._aux_cargado or self._bal_cargado):
            return

        tk.Label(self.resumen_frame, text="Vista previa",
                 bg=COLOR_BG, fg=COLOR_PRIMARY,
                 font=('Arial', 12, 'bold')).pack(anchor='w', pady=(5, 10))

        if self._aux_cargado:
            aux = self._datos_auxiliar
            grupo = tk.LabelFrame(self.resumen_frame, text=" Retenciones a terceros ",
                                   bg=COLOR_BG, fg=COLOR_PRIMARY,
                                   font=('Arial', 10, 'bold'), padx=10, pady=8)
            grupo.pack(fill=tk.X, pady=5)

            por_cuenta = {}
            for m in aux['movimientos']:
                key = (m['cuenta'], m['nombre_cuenta'])
                if key not in por_cuenta:
                    por_cuenta[key] = {'base': 0, 'retencion': 0, 'n': 0}
                por_cuenta[key]['base'] += m['base']
                por_cuenta[key]['retencion'] += m['retencion']
                por_cuenta[key]['n'] += 1

            for (cuenta, nombre), tot in por_cuenta.items():
                fila = tk.Frame(grupo, bg=COLOR_BG)
                fila.pack(fill=tk.X, pady=2)
                tk.Label(fila, text=f"  {cuenta}  {nombre[:35]}",
                         bg=COLOR_BG, font=('Arial', 9)).pack(side=tk.LEFT)
                tk.Label(fila, text=f"{formato_moneda(tot['retencion'])}  ({tot['n']} mov)",
                         bg=COLOR_BG, fg=COLOR_PRIMARY, font=('Arial', 9, 'bold')).pack(side=tk.RIGHT)

            total_ret = sum(m['retencion'] for m in aux['movimientos'])
            total_fila = tk.Frame(grupo, bg=COLOR_SECONDARY)
            total_fila.pack(fill=tk.X, pady=(8, 0))
            tk.Label(total_fila, text="  TOTAL retenciones a terceros",
                     bg=COLOR_SECONDARY, font=('Arial', 10, 'bold')).pack(side=tk.LEFT, pady=4)
            tk.Label(total_fila, text=formato_moneda(total_ret),
                     bg=COLOR_SECONDARY, fg=COLOR_PRIMARY,
                     font=('Arial', 11, 'bold')).pack(side=tk.RIGHT, pady=4)

        if self._bal_cargado:
            tarifa = self.decl_empresa['tarifa_autorretencion'] * 100
            auto = calcular_autorretencion_cuenta_4(self._datos_balance, tarifa)
            if auto:
                grupo2 = tk.LabelFrame(self.resumen_frame, text=" Autorretención especial (cuenta 4) ",
                                        bg=COLOR_BG, fg=COLOR_PRIMARY,
                                        font=('Arial', 10, 'bold'), padx=10, pady=8)
                grupo2.pack(fill=tk.X, pady=5)
                datos_auto = [
                    ("  Cuenta 41 (operacionales) neto", auto['cuenta_41_neto']),
                    ("  Cuenta 42 (no operacionales) neto", auto['cuenta_42_neto']),
                    (f"  Base autorretención × {tarifa:.2f}%", auto['ingresos_netos']),
                    ("  AUTORRETENCIÓN a pagar", auto['autorretencion']),
                ]
                for i, (etiq, val) in enumerate(datos_auto):
                    fila = tk.Frame(grupo2, bg=COLOR_BG if i < 3 else COLOR_SECONDARY)
                    fila.pack(fill=tk.X, pady=1)
                    tk.Label(fila, text=etiq,
                             bg=fila['bg'],
                             font=('Arial', 10 if i == 3 else 9, 'bold' if i == 3 else 'normal')
                             ).pack(side=tk.LEFT, pady=3)
                    tk.Label(fila, text=formato_moneda(val),
                             bg=fila['bg'], fg=COLOR_PRIMARY,
                             font=('Arial', 11 if i == 3 else 10,
                                   'bold' if i == 3 else 'normal')
                             ).pack(side=tk.RIGHT, pady=3)

    def _procesar_archivos(self):
        """Toma los datos parseados y los inserta en la BD."""
        if not (self._aux_cargado or self._bal_cargado):
            messagebox.showwarning("Sin datos", "Carga al menos un archivo primero")
            return

        cursor = self.db.conn.cursor()
        cursor.execute("DELETE FROM movimientos_declaracion WHERE declaracion_id = ?",
                       (self.decl_actual_id,))

        total_ret = 0
        if self._aux_cargado:
            for m in self._datos_auxiliar['movimientos']:
                tipo, es_ext, valido, _ = inferir_tipo_persona(m['nit'])
                concepto = clasificar_concepto_por_cuenta(m['cuenta'], m['nombre_cuenta'])

                if concepto == 'IVA':
                    casilla = 131
                elif es_ext:
                    casilla = 57
                else:
                    tipo_key = "PN" if tipo == "Persona Natural" else "PJ"
                    if concepto in MAPEO_CASILLAS_F350:
                        cas_base, cas_ret = MAPEO_CASILLAS_F350[concepto][tipo_key]
                        casilla = cas_ret if cas_ret else 54
                    else:
                        casilla = 54 if tipo_key == "PJ" else 108

                cursor.execute("""
                    INSERT INTO movimientos_declaracion
                    (declaracion_id, cuenta_puc, nit_tercero, nombre_tercero,
                     tipo_inferido, es_extranjero, base, tarifa, retencion,
                     casilla_destino, concepto_asignado, estado)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, (self.decl_actual_id, m['cuenta'], m['nit'], m['nombre_tercero'],
                      tipo, 1 if es_ext else 0, m['base'], m['tarifa_mov'], m['retencion'],
                      casilla, m['nombre_cuenta'] or 'Retención', 'ok'))
                total_ret += m['retencion']

        valor_autorr = 0
        base_autorr = 0
        if self._bal_cargado:
            tarifa = self.decl_empresa['tarifa_autorretencion'] * 100
            auto = calcular_autorretencion_cuenta_4(self._datos_balance, tarifa)
            if auto and auto['autorretencion'] > 0:
                valor_autorr = auto['autorretencion']
                base_autorr = auto['ingresos_netos']

                nit_propio = self.decl_empresa['nit']
                cursor.execute("""
                    INSERT INTO movimientos_declaracion
                    (declaracion_id, cuenta_puc, nit_tercero, nombre_tercero,
                     tipo_inferido, es_extranjero, base, tarifa, retencion,
                     casilla_destino, concepto_asignado, estado)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, (self.decl_actual_id, '4', nit_propio, self.decl_empresa['razon_social'],
                      'Persona Jurídica', 0, base_autorr, tarifa, valor_autorr,
                      78, 'Autorretención especial', 'ok'))

        cursor.execute("""
            UPDATE declaraciones SET
              base_autorretencion = ?,
              valor_autorretencion = ?,
              total_retenciones_renta = ?,
              total_declaracion = ?
            WHERE id = ?
        """, (base_autorr, valor_autorr, total_ret, total_ret + valor_autorr,
              self.decl_actual_id))
        self.db.conn.commit()

        messagebox.showinfo(
            "Procesado",
            f"✓ Datos cargados correctamente:\n\n"
            f"Retenciones a terceros:  {formato_moneda(total_ret)}\n"
            f"Autorretención especial: {formato_moneda(valor_autorr)}\n"
            f"TOTAL borrador 350:      {formato_moneda(total_ret + valor_autorr)}"
        )
        self.mostrar_ficha_diligenciamiento(self.decl_actual_id)

    def mostrar_ingreso_manual(self, decl_id):
        """Pantalla de ingreso manual - respaldo si falla el parser PDF."""
        self.limpiar_contenido()
        self.decl_actual_id = decl_id

        cursor = self.db.conn.cursor()
        cursor.execute("""
            SELECT d.*, e.razon_social, e.nit, e.ciiu_principal, e.tarifa_autorretencion,
                   e.es_autorretenedor
            FROM declaraciones d JOIN empresas e ON d.empresa_id = e.id
            WHERE d.id = ?
        """, (decl_id,))
        decl = cursor.fetchone()

        meses = ['', 'Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio',
                 'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre']

        header = tk.Frame(self.contenido_frame, bg=COLOR_BG)
        header.pack(fill=tk.X, pady=(0, 15))
        tk.Label(header, text=f"Ingreso manual — {meses[decl['mes']]} {decl['año']}",
                 bg=COLOR_BG, fg=COLOR_PRIMARY,
                 font=('Arial', 18, 'bold')).pack(anchor='w')
        tk.Label(header,
                 text=f"{decl['razon_social']} · Modo respaldo — usa esto si el parser PDF falla",
                 bg=COLOR_BG, fg=COLOR_TEXT_SECONDARY,
                 font=('Arial', 10)).pack(anchor='w')

        tk.Button(header, text="← Volver a carga automática",
                  bg=COLOR_SECONDARY, fg=COLOR_PRIMARY,
                  font=('Arial', 9), padx=10, pady=5, bd=0,
                  cursor='hand2',
                  command=lambda: self.mostrar_ingreso_movimientos(decl_id)).pack(side=tk.RIGHT)

        form = tk.LabelFrame(self.contenido_frame, text=" Nuevo movimiento ",
                             bg=COLOR_BG, fg=COLOR_PRIMARY,
                             font=('Arial', 10, 'bold'), padx=15, pady=10)
        form.pack(fill=tk.X, pady=10)

        fila1 = tk.Frame(form, bg=COLOR_BG)
        fila1.pack(fill=tk.X, pady=4)
        tk.Label(fila1, text="NIT tercero:", bg=COLOR_BG, width=15, anchor='w',
                 font=('Arial', 10)).pack(side=tk.LEFT)
        self.mov_nit = tk.Entry(fila1, font=('Arial', 10), width=20)
        self.mov_nit.pack(side=tk.LEFT, padx=5)
        tk.Button(fila1, text="Validar", bg=COLOR_SECONDARY, fg=COLOR_PRIMARY,
                  font=('Arial', 9), bd=0, padx=10,
                  command=self._validar_nit_movimiento).pack(side=tk.LEFT, padx=5)
        self.mov_tipo_label = tk.Label(fila1, text="", bg=COLOR_BG,
                                        fg=COLOR_TEXT_SECONDARY, font=('Arial', 9, 'italic'))
        self.mov_tipo_label.pack(side=tk.LEFT, padx=10)

        fila2 = tk.Frame(form, bg=COLOR_BG)
        fila2.pack(fill=tk.X, pady=4)
        tk.Label(fila2, text="Nombre/Razón:", bg=COLOR_BG, width=15, anchor='w',
                 font=('Arial', 10)).pack(side=tk.LEFT)
        self.mov_nombre = tk.Entry(fila2, font=('Arial', 10), width=45)
        self.mov_nombre.pack(side=tk.LEFT, padx=5)

        fila3 = tk.Frame(form, bg=COLOR_BG)
        fila3.pack(fill=tk.X, pady=4)
        tk.Label(fila3, text="Concepto:", bg=COLOR_BG, width=15, anchor='w',
                 font=('Arial', 10)).pack(side=tk.LEFT)
        conceptos = [
            "Salarios y pagos laborales",
            "Honorarios",
            "Comisiones",
            "Servicios generales",
            "Arrendamientos bienes raíces",
            "Arrendamientos bienes muebles",
            "Compras de bienes",
            "Rendimientos financieros",
            "Loterías, rifas, apuestas",
            "Dividendos y participaciones",
            "IVA - Retención 15%",
            "IVA - Retención 100%",
            "Autorretención especial",
            "Otros conceptos renta",
            "Pagos al exterior",
        ]
        self.mov_concepto = ttk.Combobox(fila3, values=conceptos, state='readonly',
                                          font=('Arial', 10), width=43)
        self.mov_concepto.pack(side=tk.LEFT, padx=5)

        fila4 = tk.Frame(form, bg=COLOR_BG)
        fila4.pack(fill=tk.X, pady=4)
        tk.Label(fila4, text="Base ($):", bg=COLOR_BG, width=15, anchor='w',
                 font=('Arial', 10)).pack(side=tk.LEFT)
        self.mov_base = tk.Entry(fila4, font=('Arial', 10), width=20)
        self.mov_base.pack(side=tk.LEFT, padx=5)
        tk.Label(fila4, text="Tarifa (%):", bg=COLOR_BG,
                 font=('Arial', 10)).pack(side=tk.LEFT, padx=(20, 5))
        self.mov_tarifa = tk.Entry(fila4, font=('Arial', 10), width=10)
        self.mov_tarifa.pack(side=tk.LEFT, padx=5)
        tk.Label(fila4, text="Retención ($):", bg=COLOR_BG,
                 font=('Arial', 10)).pack(side=tk.LEFT, padx=(20, 5))
        self.mov_retencion = tk.Entry(fila4, font=('Arial', 10), width=20)
        self.mov_retencion.pack(side=tk.LEFT, padx=5)

        tk.Button(fila4, text="Calcular", bg=COLOR_SECONDARY, fg=COLOR_PRIMARY,
                  font=('Arial', 9), bd=0, padx=10,
                  command=self._calcular_retencion_movimiento).pack(side=tk.LEFT, padx=10)

        btns = tk.Frame(form, bg=COLOR_BG)
        btns.pack(fill=tk.X, pady=(10, 0))
        tk.Button(btns, text="➕ Agregar movimiento",
                  bg=COLOR_PRIMARY, fg='white',
                  font=('Arial', 10, 'bold'), padx=15, pady=6, bd=0,
                  cursor='hand2',
                  command=self._agregar_movimiento).pack(side=tk.LEFT, padx=5)
        tk.Button(btns, text="🧹 Limpiar",
                  bg='#CCCCCC', fg=COLOR_TEXT,
                  font=('Arial', 10), padx=15, pady=6, bd=0,
                  cursor='hand2',
                  command=self._limpiar_form_movimiento).pack(side=tk.LEFT, padx=5)

        lista_frame = tk.LabelFrame(self.contenido_frame, text=" Movimientos ingresados ",
                                    bg=COLOR_BG, fg=COLOR_PRIMARY,
                                    font=('Arial', 10, 'bold'), padx=10, pady=10)
        lista_frame.pack(fill=tk.BOTH, expand=True, pady=10)

        tree_container = tk.Frame(lista_frame, bg=COLOR_BG)
        tree_container.pack(fill=tk.BOTH, expand=True)

        cols = ("NIT", "Tercero", "Concepto", "Base", "Tarifa", "Retención")
        self.tree_movs = ttk.Treeview(tree_container, columns=cols, show='headings', height=8)
        anchos = [100, 180, 160, 110, 60, 110]
        for c, w in zip(cols, anchos):
            self.tree_movs.heading(c, text=c)
            self.tree_movs.column(c, width=w, anchor='w' if c in ('NIT', 'Tercero', 'Concepto') else 'e')

        scrollbar = ttk.Scrollbar(tree_container, orient='vertical', command=self.tree_movs.yview)
        self.tree_movs.configure(yscroll=scrollbar.set)
        self.tree_movs.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

        self.tree_movs.bind('<Double-1>', self._eliminar_movimiento)

        tk.Label(lista_frame, text="Doble clic sobre un movimiento para eliminarlo",
                 bg=COLOR_BG, fg=COLOR_TEXT_SECONDARY,
                 font=('Arial', 8, 'italic')).pack(anchor='w', pady=(4, 0))

        self._recargar_movimientos()

        totales_frame = tk.Frame(self.contenido_frame, bg=COLOR_SECONDARY, padx=15, pady=10)
        totales_frame.pack(fill=tk.X, pady=10)
        self.label_totales = tk.Label(totales_frame, text="", bg=COLOR_SECONDARY,
                                       fg=COLOR_PRIMARY, font=('Arial', 11, 'bold'),
                                       justify='left')
        self.label_totales.pack(anchor='w')
        self._actualizar_totales()

        footer = tk.Frame(self.contenido_frame, bg=COLOR_BG)
        footer.pack(fill=tk.X, pady=10)
        tk.Button(footer, text="📄 Generar Ficha de Diligenciamiento →",
                  bg=COLOR_PRIMARY, fg='white',
                  font=('Arial', 11, 'bold'), padx=20, pady=10, bd=0,
                  cursor='hand2',
                  command=self._generar_ficha).pack(side=tk.LEFT, padx=5)

    def _validar_nit_movimiento(self):
        nit = self.mov_nit.get().strip()
        if not nit:
            self.mov_tipo_label.config(text="Ingresa un NIT", fg=COLOR_TEXT_SECONDARY)
            return
        tipo, es_ext, valido, rango = inferir_tipo_persona(nit)
        if not valido:
            self.mov_tipo_label.config(text=f"⚠️ {rango}", fg='#C00000')
        else:
            marca = " · EXTRANJERO" if es_ext else ""
            self.mov_tipo_label.config(text=f"✓ {tipo}{marca}",
                                        fg=COLOR_PRIMARY)

    def _calcular_retencion_movimiento(self):
        try:
            base = float(self.mov_base.get().replace('.', '').replace(',', '.') or 0)
            tarifa_txt = self.mov_tarifa.get().replace(',', '.')
            tarifa = float(tarifa_txt or 0)

            retencion = round(base * tarifa / 100)
            self.mov_retencion.delete(0, tk.END)
            self.mov_retencion.insert(0, str(retencion))
        except ValueError:
            messagebox.showerror("Error", "Base y tarifa deben ser números")

    def _limpiar_form_movimiento(self):
        self.mov_nit.delete(0, tk.END)
        self.mov_nombre.delete(0, tk.END)
        self.mov_concepto.set('')
        self.mov_base.delete(0, tk.END)
        self.mov_tarifa.delete(0, tk.END)
        self.mov_retencion.delete(0, tk.END)
        self.mov_tipo_label.config(text="")

    def _agregar_movimiento(self):
        nit = self.mov_nit.get().strip()
        nombre = self.mov_nombre.get().strip()
        concepto = self.mov_concepto.get().strip()

        if not nit or not nombre:
            messagebox.showerror("Error", "NIT y nombre son obligatorios")
            return
        if not concepto:
            messagebox.showerror("Error", "Debes seleccionar un concepto")
            return

        try:
            base = float(self.mov_base.get().replace('.', '').replace(',', '.') or 0)
            tarifa = float(self.mov_tarifa.get().replace(',', '.') or 0)
            retencion_txt = self.mov_retencion.get().replace('.', '').replace(',', '.')
            retencion = float(retencion_txt or 0)
        except ValueError:
            messagebox.showerror("Error", "Base, tarifa y retención deben ser números")
            return

        if base <= 0 or retencion <= 0:
            messagebox.showerror("Error", "Base y retención deben ser mayores a cero")
            return

        tipo, es_ext, valido, rango = inferir_tipo_persona(nit)
        if not valido:
            resp = messagebox.askyesno(
                "NIT inválido",
                f"El NIT {nit} está fuera de rangos conocidos ({rango}).\n\n"
                "¿Deseas registrarlo de todas formas?"
            )
            if not resp:
                return

        casilla = self._mapear_casilla(concepto, tipo, es_ext)

        cursor = self.db.conn.cursor()
        nit_limpio = ''.join(c for c in nit if c.isdigit())
        cursor.execute("""
            INSERT INTO movimientos_declaracion
            (declaracion_id, cuenta_puc, nit_tercero, nombre_tercero,
             tipo_inferido, es_extranjero, base, tarifa, retencion,
             casilla_destino, concepto_asignado, estado)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (self.decl_actual_id, '', nit_limpio, nombre,
              tipo, 1 if es_ext else 0, base, tarifa, retencion,
              casilla, concepto, 'ok'))
        self.db.conn.commit()

        self._limpiar_form_movimiento()
        self._recargar_movimientos()
        self._actualizar_totales()

    def _mapear_casilla(self, concepto, tipo, es_extranjero):
        """
        Mapea un concepto + tipo de tercero a la casilla de RETENCIÓN del F350 vigente.
        Basado en el formulario oficial DIAN 2024 (Res. 000031/2024).
        """
        mapa = {
            "Salarios y pagos laborales":   {"PN": 93,  "PJ": None},
            "Honorarios":                   {"PN": 95,  "PJ": 42},
            "Comisiones":                   {"PN": 96,  "PJ": 43},
            "Servicios generales":          {"PN": 97,  "PJ": 44},
            "Arrendamientos bienes raíces": {"PN": 99,  "PJ": 46},
            "Arrendamientos bienes muebles":{"PN": 99,  "PJ": 46},
            "Compras de bienes":            {"PN": 102, "PJ": 49},
            "Rendimientos financieros":     {"PN": 98,  "PJ": 45},
            "Loterías, rifas, apuestas":    {"PN": 106, "PJ": 52},
            "Dividendos y participaciones": {"PN": 101, "PJ": 48},
            "Otros conceptos renta":        {"PN": 108, "PJ": 54},
            "IVA - Retención 15%":          {"PN": 131, "PJ": 131},
            "IVA - Retención 100%":         {"PN": 131, "PJ": 131},
            "Autorretención especial":      {"PN": 78,  "PJ": 78},
            "Pagos al exterior":            {"PN": 111, "PJ": 57},
        }
        if concepto == "Pagos al exterior" or es_extranjero:
            return 57
        clase = "PJ" if tipo == "Persona Jurídica" else "PN"
        if concepto in mapa:
            cas = mapa[concepto].get(clase)
            return cas if cas else (54 if clase == "PJ" else 108)
        return 54 if clase == "PJ" else 108

    def _recargar_movimientos(self):
        for item in self.tree_movs.get_children():
            self.tree_movs.delete(item)
        cursor = self.db.conn.cursor()
        cursor.execute("""
            SELECT id, nit_tercero, nombre_tercero, concepto_asignado,
                   base, tarifa, retencion
            FROM movimientos_declaracion
            WHERE declaracion_id = ?
            ORDER BY id DESC
        """, (self.decl_actual_id,))
        for row in cursor.fetchall():
            self.tree_movs.insert('', tk.END, iid=str(row['id']), values=(
                formato_nit(row['nit_tercero']),
                row['nombre_tercero'][:30],
                row['concepto_asignado'][:25],
                formato_moneda(row['base']),
                f"{row['tarifa']:.2f}%",
                formato_moneda(row['retencion'])
            ))

    def _eliminar_movimiento(self, event):
        item = self.tree_movs.selection()
        if not item:
            return
        mov_id = int(item[0])
        resp = messagebox.askyesno("Confirmar", "¿Eliminar este movimiento?")
        if not resp:
            return
        cursor = self.db.conn.cursor()
        cursor.execute("DELETE FROM movimientos_declaracion WHERE id=?", (mov_id,))
        self.db.conn.commit()
        self._recargar_movimientos()
        self._actualizar_totales()

    def _actualizar_totales(self):
        cursor = self.db.conn.cursor()
        cursor.execute("""
            SELECT COUNT(*) as cantidad,
                   COALESCE(SUM(base), 0) as total_base,
                   COALESCE(SUM(retencion), 0) as total_ret
            FROM movimientos_declaracion WHERE declaracion_id = ?
        """, (self.decl_actual_id,))
        row = cursor.fetchone()
        texto = (f"Movimientos: {row['cantidad']}   |   "
                 f"Total bases: {formato_moneda(row['total_base'])}   |   "
                 f"Total retenciones: {formato_moneda(row['total_ret'])}")
        self.label_totales.config(text=texto)

    def _generar_ficha(self):
        """Genera la Ficha de Diligenciamiento consolidada por casilla."""
        cursor = self.db.conn.cursor()
        cursor.execute("SELECT COUNT(*) FROM movimientos_declaracion WHERE declaracion_id=?",
                       (self.decl_actual_id,))
        cant = cursor.fetchone()[0]
        if cant == 0:
            messagebox.showwarning("Sin movimientos",
                                    "Debes ingresar al menos un movimiento antes de generar la ficha.")
            return

        cursor.execute("""
            UPDATE declaraciones SET
              total_retenciones_renta = (
                  SELECT COALESCE(SUM(retencion), 0)
                  FROM movimientos_declaracion
                  WHERE declaracion_id = ? AND casilla_destino < 84
              ),
              total_declaracion = (
                  SELECT COALESCE(SUM(retencion), 0)
                  FROM movimientos_declaracion
                  WHERE declaracion_id = ?
              )
            WHERE id = ?
        """, (self.decl_actual_id, self.decl_actual_id, self.decl_actual_id))
        self.db.conn.commit()

        self.mostrar_ficha_diligenciamiento(self.decl_actual_id)

    def mostrar_ficha_diligenciamiento(self, decl_id):
        """Pantalla final con las casillas del 350 listas para copiar a Muisca."""
        self.limpiar_contenido()
        self.decl_actual_id = decl_id

        cursor = self.db.conn.cursor()
        cursor.execute("""
            SELECT d.*, e.razon_social, e.nit
            FROM declaraciones d JOIN empresas e ON d.empresa_id = e.id
            WHERE d.id = ?
        """, (decl_id,))
        decl = cursor.fetchone()

        meses = ['', 'Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio',
                 'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre']

        header = tk.Frame(self.contenido_frame, bg=COLOR_BG)
        header.pack(fill=tk.X, pady=(0, 10))
        tk.Label(header, text="Ficha de Diligenciamiento · Formulario 350",
                 bg=COLOR_BG, fg=COLOR_PRIMARY,
                 font=('Arial', 18, 'bold')).pack(anchor='w')
        tk.Label(header,
                 text=f"{decl['razon_social']} · {meses[decl['mes']]} {decl['año']} · NIT {formato_nit(decl['nit'])}",
                 bg=COLOR_BG, fg=COLOR_TEXT_SECONDARY,
                 font=('Arial', 10)).pack(anchor='w')

        tk.Button(header, text="← Volver a movimientos",
                  bg='#CCCCCC', fg=COLOR_TEXT,
                  font=('Arial', 9), padx=10, pady=5, bd=0,
                  cursor='hand2',
                  command=lambda: self.mostrar_ingreso_movimientos(decl_id)).pack(side=tk.RIGHT)

        instr = tk.Frame(self.contenido_frame, bg=COLOR_SUCCESS, padx=15, pady=10)
        instr.pack(fill=tk.X, pady=(0, 10))
        tk.Label(instr,
                 text="✅ Abre Muisca en tu navegador → Formulario 350 → período correspondiente → "
                      "copia cada valor con el botón 📋 al lado de cada casilla. "
                      "Los demás campos aparecerán como $0 o vacíos, es normal — tú solo diligencias las casillas con valor.",
                 bg=COLOR_SUCCESS, font=('Arial', 9, 'italic'),
                 wraplength=750, justify='left').pack()

        cursor.execute("""
            SELECT casilla_destino, concepto_asignado,
                   COUNT(*) as n,
                   COALESCE(SUM(base), 0) as base_total,
                   COALESCE(SUM(retencion), 0) as ret_total
            FROM movimientos_declaracion
            WHERE declaracion_id = ?
            GROUP BY casilla_destino, concepto_asignado
            ORDER BY casilla_destino
        """, (decl_id,))
        agrupado = cursor.fetchall()

        secciones = {
            'Retenciones a título de Renta': [],
            'Retenciones IVA': [],
            'Autorretención especial': [],
            'Pagos al exterior': [],
        }
        for row in agrupado:
            c = row['casilla_destino']
            if c < 78:
                secciones['Retenciones a título de Renta'].append(row)
            elif c == 78:
                secciones['Autorretención especial'].append(row)
            elif c in (84, 85):
                secciones['Retenciones IVA'].append(row)
            else:
                secciones['Pagos al exterior'].append(row)

        canvas = tk.Canvas(self.contenido_frame, bg=COLOR_BG, highlightthickness=0)
        scroll = ttk.Scrollbar(self.contenido_frame, orient='vertical', command=canvas.yview)
        canvas.configure(yscrollcommand=scroll.set)

        inner = tk.Frame(canvas, bg=COLOR_BG)
        canvas.create_window((0, 0), window=inner, anchor='nw')
        inner.bind('<Configure>', lambda e: canvas.configure(scrollregion=canvas.bbox('all')))

        canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scroll.pack(side=tk.RIGHT, fill=tk.Y)

        def _mousewheel(e):
            canvas.yview_scroll(int(-1*(e.delta/120)), 'units')
        canvas.bind_all('<MouseWheel>', _mousewheel)

        total_general_ret = 0

        for nombre_sec, items in secciones.items():
            if not items:
                continue
            sec_frame = tk.LabelFrame(inner, text=f"  {nombre_sec}  ",
                                       bg=COLOR_BG, fg=COLOR_PRIMARY,
                                       font=('Arial', 11, 'bold'), padx=10, pady=10)
            sec_frame.pack(fill=tk.X, pady=5, padx=5)

            encabezado = tk.Frame(sec_frame, bg=COLOR_SECONDARY, pady=6)
            encabezado.pack(fill=tk.X)
            tk.Label(encabezado, text="Casilla", bg=COLOR_SECONDARY,
                     fg=COLOR_PRIMARY, font=('Arial', 9, 'bold'),
                     width=8).pack(side=tk.LEFT, padx=5)
            tk.Label(encabezado, text="Concepto", bg=COLOR_SECONDARY,
                     fg=COLOR_PRIMARY, font=('Arial', 9, 'bold'),
                     width=35, anchor='w').pack(side=tk.LEFT, padx=5)
            tk.Label(encabezado, text="Base", bg=COLOR_SECONDARY,
                     fg=COLOR_PRIMARY, font=('Arial', 9, 'bold'),
                     width=15, anchor='e').pack(side=tk.LEFT, padx=5)
            tk.Label(encabezado, text="Valor retención", bg=COLOR_SECONDARY,
                     fg=COLOR_PRIMARY, font=('Arial', 9, 'bold'),
                     width=15, anchor='e').pack(side=tk.LEFT, padx=5)
            tk.Label(encabezado, text="Copiar", bg=COLOR_SECONDARY,
                     fg=COLOR_PRIMARY, font=('Arial', 9, 'bold'),
                     width=10).pack(side=tk.LEFT, padx=5)

            for item in items:
                casilla = item['casilla_destino']
                concepto = item['concepto_asignado']
                base = aproximar_a_miles(item['base_total'])
                ret = aproximar_a_miles(item['ret_total'])
                total_general_ret += ret

                fila = tk.Frame(sec_frame, bg='white', pady=4)
                fila.pack(fill=tk.X, pady=1)

                tk.Label(fila, text=str(casilla), bg='white',
                         fg=COLOR_PRIMARY, font=('Arial', 11, 'bold'),
                         width=8).pack(side=tk.LEFT, padx=5)
                tk.Label(fila, text=concepto, bg='white',
                         fg=COLOR_TEXT, font=('Arial', 10),
                         width=35, anchor='w').pack(side=tk.LEFT, padx=5)
                tk.Label(fila, text=formato_moneda(base), bg='white',
                         fg=COLOR_TEXT_SECONDARY, font=('Arial', 10),
                         width=15, anchor='e').pack(side=tk.LEFT, padx=5)
                valor_label = tk.Label(fila, text=formato_moneda(ret), bg='white',
                                        fg=COLOR_PRIMARY, font=('Arial', 11, 'bold'),
                                        width=15, anchor='e')
                valor_label.pack(side=tk.LEFT, padx=5)
                tk.Button(fila, text="📋 Copiar",
                          bg=COLOR_SECONDARY, fg=COLOR_PRIMARY,
                          font=('Arial', 9), bd=0, padx=8, pady=2,
                          cursor='hand2',
                          command=lambda v=int(round(ret)): self._copiar_al_portapapeles(v)).pack(side=tk.LEFT, padx=5)

        total_frame = tk.Frame(inner, bg=COLOR_PRIMARY, padx=15, pady=12)
        total_frame.pack(fill=tk.X, pady=15, padx=5)
        tk.Label(total_frame, text="TOTAL RETENCIONES A PAGAR",
                 bg=COLOR_PRIMARY, fg='white',
                 font=('Arial', 11, 'bold')).pack(side=tk.LEFT)
        tk.Label(total_frame, text=formato_moneda(total_general_ret),
                 bg=COLOR_PRIMARY, fg='white',
                 font=('Arial', 14, 'bold')).pack(side=tk.RIGHT)

        acciones_frame = tk.Frame(inner, bg=COLOR_BG)
        acciones_frame.pack(fill=tk.X, pady=10, padx=5)
        tk.Button(acciones_frame, text="📄 Exportar PDF · Formulario 350",
                  bg=COLOR_PRIMARY, fg='white',
                  font=('Arial', 10, 'bold'), padx=15, pady=8, bd=0,
                  cursor='hand2',
                  command=lambda: self._exportar_ficha_pdf(decl_id)).pack(side=tk.LEFT, padx=5)
        tk.Button(acciones_frame, text="✅ Marcar como presentada",
                  bg=COLOR_SUCCESS, fg=COLOR_TEXT,
                  font=('Arial', 10), padx=15, pady=8, bd=0,
                  cursor='hand2',
                  command=lambda: self._marcar_presentada(decl_id)).pack(side=tk.LEFT, padx=5)
        tk.Button(acciones_frame, text="🏠 Volver al dashboard",
                  bg='#CCCCCC', fg=COLOR_TEXT,
                  font=('Arial', 10), padx=15, pady=8, bd=0,
                  cursor='hand2',
                  command=self.mostrar_dashboard).pack(side=tk.LEFT, padx=5)

    def _copiar_al_portapapeles(self, valor):
        self.root.clipboard_clear()
        self.root.clipboard_append(str(valor))
        self.root.update()
        messagebox.showinfo("Copiado", f"Valor copiado al portapapeles: {formato_moneda(valor)}\n\n"
                                         "Pégalo en la casilla correspondiente de Muisca con Ctrl+V.")

    def _exportar_ficha_pdf(self, decl_id):
        """Genera PDF del Formulario 350 estilo DIAN."""
        cursor = self.db.conn.cursor()
        cursor.execute("""
            SELECT d.*, e.razon_social, e.nit, e.dv, e.ciiu_principal,
                   e.tarifa_autorretencion, e.es_autorretenedor, e.exonerado_art_114_1
            FROM declaraciones d JOIN empresas e ON d.empresa_id = e.id
            WHERE d.id = ?
        """, (decl_id,))
        decl = cursor.fetchone()

        cursor.execute("""
            SELECT cuenta_puc, concepto_asignado, nit_tercero, tipo_inferido,
                   es_extranjero, base, retencion, casilla_destino
            FROM movimientos_declaracion
            WHERE declaracion_id = ?
        """, (decl_id,))
        movimientos = cursor.fetchall()

        retenciones_list = []
        autorretenciones_list = []
        total_iva = 0

        for m in movimientos:
            if m['casilla_destino'] == 78 or m['concepto_asignado'] == 'Autorretención especial':
                autorretenciones_list.append({
                    'concepto': 'Contribuyentes exonerados 114-1',
                    'base': m['base'],
                    'retencion': m['retencion'],
                })
                continue

            concepto = clasificar_concepto_por_cuenta(m['cuenta_puc'], m['concepto_asignado'])

            if concepto == 'IVA':
                total_iva += m['retencion']
                continue

            tipo = 'PN' if m['tipo_inferido'] == 'Persona Natural' else 'PJ'
            retenciones_list.append({
                'concepto': concepto,
                'tipo': tipo,
                'base': m['base'],
                'retencion': m['retencion'],
            })

        meses = ['', 'Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio',
                 'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre']

        datos = {
            'año': decl['año'],
            'periodo': decl['mes'],
            'nit': decl['nit'],
            'dv': decl['dv'] or '',
            'razon_social': decl['razon_social'],
            'ciiu': decl['ciiu_principal'] or '',
            'tarifa_autorret': (decl['tarifa_autorretencion'] or 0) * 100,
            'retenciones': retenciones_list,
            'autorretenciones': autorretenciones_list,
            'total_iva': total_iva,
            'total_timbre': 0,
        }

        nombre_sugerido = f"F350_{decl['razon_social'][:20].replace(' ', '_')}_{meses[decl['mes']]}_{decl['año']}.pdf"
        ruta = filedialog.asksaveasfilename(
            defaultextension=".pdf",
            filetypes=[("PDF", "*.pdf")],
            initialfile=nombre_sugerido
        )
        if not ruta:
            return

        try:
            generar_pdf_formulario_350(ruta, datos)
            messagebox.showinfo(
                "PDF generado",
                f"✓ Formulario 350 (borrador) exportado a:\n\n{ruta}\n\n"
                "El PDF tiene el layout similar al oficial DIAN.\n"
                "Úsalo como referencia al diligenciar en Muisca."
            )
            try:
                if sys.platform == 'win32':
                    os.startfile(ruta)
                elif sys.platform == 'darwin':
                    os.system(f'open "{ruta}"')
                else:
                    os.system(f'xdg-open "{ruta}"')
            except Exception:
                pass
        except Exception as e:
            messagebox.showerror(
                "Error al generar PDF",
                f"No se pudo generar el PDF:\n\n{e}\n\n"
                "Asegúrate de tener reportlab instalado:\n"
                "pip install reportlab"
            )

    def _marcar_presentada(self, decl_id):
        resp = messagebox.askyesno(
            "Confirmar",
            "¿Marcar esta declaración como PRESENTADA ante la DIAN?\n\n"
            "Esto solo cambia el estado en la app. Asegúrate de haberla radicado en Muisca."
        )
        if not resp:
            return
        cursor = self.db.conn.cursor()
        cursor.execute("UPDATE declaraciones SET estado='Presentada' WHERE id=?", (decl_id,))
        self.db.conn.commit()
        messagebox.showinfo("Listo", "Declaración marcada como presentada")
        self.mostrar_declaraciones()

    def mostrar_ayuda(self):
        self.limpiar_contenido()

        tk.Label(self.contenido_frame, text="Ayuda",
                 bg=COLOR_BG, fg=COLOR_PRIMARY,
                 font=('Arial', 18, 'bold')).pack(anchor='w', pady=(0, 20))

        contenido = [
            ("Acerca de BorradorFácil 350",
             "Esta aplicación te ayuda a generar borradores del Formulario 350 de retenciones "
             "en la fuente de la DIAN. Automatiza la clasificación de terceros por NIT, "
             "aplica las tarifas del Decreto 0572 de 2025 y valida los cálculos de autorretención."),

            ("Regla del NIT",
             "La app aplica automáticamente la regla oficial para clasificar NITs:\n"
             "• 10.000 a 99.999.999 → Persona Natural (cédula antigua)\n"
             "• 600M a 799.999.999 → Persona Natural EXTRANJERA\n"
             "• 800M a 999.999.999 → Persona Jurídica\n"
             "• 1.000M a 1.999.999.999 → Persona Natural (cédula moderna)"),

            ("Autorretención especial",
             "Se calcula sobre la CUENTA 4 COMPLETA del PUC (créditos menos débitos), "
             "no solo sobre ingresos operacionales. La tarifa depende del CIIU vigente en "
             "la fecha de la declaración según Decreto 0572/2025."),

            ("Soporte",
             "Para dudas o reportes, contacta al proveedor. Esta es una herramienta de apoyo; "
             "la declaración final ante la DIAN es responsabilidad del contador firmante."),
        ]

        for titulo, texto in contenido:
            seccion = tk.Frame(self.contenido_frame, bg=COLOR_BG)
            seccion.pack(fill=tk.X, pady=10)
            tk.Label(seccion, text=titulo,
                     bg=COLOR_BG, fg=COLOR_PRIMARY,
                     font=('Arial', 12, 'bold')).pack(anchor='w')
            tk.Label(seccion, text=texto,
                     bg=COLOR_BG, fg=COLOR_TEXT,
                     font=('Arial', 10),
                     wraplength=700, justify='left').pack(anchor='w', pady=(5, 0))


# ==========================================================
# PUNTO DE ENTRADA
# ==========================================================

def main():
    root = tk.Tk()
    app = BorradorFacilApp(root)
    root.mainloop()


if __name__ == "__main__":
    main()
