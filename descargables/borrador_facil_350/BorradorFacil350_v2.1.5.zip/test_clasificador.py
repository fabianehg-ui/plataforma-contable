"""
Pruebas del clasificador mejorado.

Compara casos típicos de retención en la fuente para verificar que:
  1. Los códigos PUC se reconocen correctamente.
  2. Los nombres ambiguos se resuelven bien.
  3. Casos nuevos que antes caían a 'Otros pagos' ahora se clasifican.
"""
import sys
sys.path.insert(0, '/home/claude/borrador_mejorado')

# Importar solo la función, sin lanzar la GUI
import importlib.util
spec = importlib.util.spec_from_file_location("bf", "/home/claude/borrador_mejorado/borrador_facil_350.py")
bf = importlib.util.module_from_spec(spec)

# Solo ejecutar las definiciones, no la GUI (que necesita tkinter)
# Lo más limpio: extraer solo las funciones que queremos probar
with open('/home/claude/borrador_mejorado/borrador_facil_350.py', 'r', encoding='utf-8') as f:
    src = f.read()

# Buscar solo desde 'REGLAS_CODIGO_PUC' hasta el final de clasificar_concepto_por_cuenta
inicio = src.index('REGLAS_CODIGO_PUC = {')
fin = src.index('def obtener_casillas_f350')
codigo_clasificador = src[inicio:fin]

# Ejecutarlo en un namespace propio
ns = {}
exec(codigo_clasificador, ns)

clasificar_detallado = ns['clasificar_concepto_detallado']
clasificar = ns['clasificar_concepto_por_cuenta']

# ----- CASOS DE PRUEBA -----
casos = [
    # (codigo, nombre, concepto_esperado, comentario)
    ("23-65-15", "RETENCION HONORARIOS",         "Honorarios",        "Código PUC directo"),
    ("236515",   "Honorarios profesionales",     "Honorarios",        "Código sin guiones"),
    ("23-65-25", "Servicios de aseo",            "Servicios",         "Código PUC directo"),
    ("23-67-05", "Retención IVA régimen común",  "IVA",               "Cuenta 23-67 → IVA"),
    ("23-65-30", "Arrendamiento bodega",         "Arrendamientos",    "Código PUC arrendamientos"),
    ("23-65-05", "Salarios y prestaciones",      "Rentas de trabajo", "Código salarios"),

    # Casos donde solo el nombre lo dice
    ("",         "VIGILANCIA PRIVADA SAS",       "Servicios",         "Vigilancia privada → servicios"),
    ("",         "REVISORIA FISCAL CIA",         "Honorarios",        "Revisoría fiscal → honorarios"),
    ("",         "VIGILANCIA FISCAL",            "Honorarios",        "Vigilancia fiscal ≠ vigilancia privada"),
    ("",         "ARRENDAMIENTO DE OFICINA",     "Arrendamientos",    "Patrón directo"),
    ("",         "ALQUILER DE VEHICULO",         "Arrendamientos",    "Sinónimo de arrendamiento"),
    ("",         "ASESORIA TRIBUTARIA",          "Honorarios",        "Asesoría + tributaria"),
    ("",         "CONSULTORIA EN SISTEMAS",      "Honorarios",        "Consultoría → honorarios"),
    ("",         "MANTENIMIENTO EQUIPOS",        "Servicios",         "Mantenimiento → servicios"),
    ("",         "TRANSPORTE DE CARGA",          "Servicios",         "Patrón combinado"),
    ("",         "CAPACITACION PERSONAL",        "Servicios",         "Patrón directo"),
    ("",         "PUBLICIDAD VALLAS",            "Servicios",         "Patrón directo"),
    ("",         "FRANQUICIA McDonalds",         "Regalías",          "Franquicia → regalías"),
    ("",         "LICENCIA DE USO DE MARCA",     "Regalías",          "Licencia + uso/marca"),
    ("",         "INTERESES PRESTAMO BANCARIO",  "Rendimientos financieros", "Patrón combinado"),
    ("",         "COMPRAS DE MERCANCIA",         "Compras",           "Patrón directo"),
    ("",         "ADQUISICION DE BIENES",        "Compras",           "Patrón combinado"),
    ("",         "PAGOS AL EXTERIOR SERVICIOS",  "Otros pagos",       "Exterior tiene prioridad"),

    # Casos ambiguos del clasificador viejo
    ("",         "Honorarios COMISION venta",    "Honorarios",        "Honorario gana sobre comisión por orden"),
    ("",         "OTROS",                        "Otros pagos",       "Default"),
    ("",         "",                             "Otros pagos",       "Vacío → default"),
]

# Ejecutar y mostrar
print(f"{'Código':<12} {'Nombre':<35} {'Esperado':<28} {'Obtenido':<28} {'Confianza':<10} {'Estado'}")
print("=" * 130)
ok = 0
fail = 0
for codigo, nombre, esperado, comentario in casos:
    detalle = clasificar_detallado(codigo, nombre)
    obtenido = detalle['concepto']
    conf = detalle['confianza']
    estado = "✓" if obtenido == esperado else "✗ FALLA"
    if obtenido == esperado:
        ok += 1
    else:
        fail += 1
    print(f"{codigo:<12} {nombre[:34]:<35} {esperado:<28} {obtenido:<28} {conf:<10} {estado}")
    if obtenido != esperado:
        print(f"             Regla aplicada: {detalle['regla']} (origen: {detalle['origen']})")

print("=" * 130)
print(f"Total: {ok} OK, {fail} FALLAN  ({ok}/{len(casos)})")
